import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {HomeComponent} from './home/home.component';
import {MatchesCardListComponent} from './courses-card-list/matches-card-list.component';
import {EditMatchDialogComponent} from './edit-match-dialog/edit-match-dialog.component';
import {MatchesHttpService} from './services/matches-http.service';
import {MatchComponent} from './match/match.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatDialogModule} from '@angular/material/dialog';
import {MatInputModule} from '@angular/material/input';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatSelectModule} from '@angular/material/select';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSortModule} from '@angular/material/sort';
import {MatTableModule} from '@angular/material/table';
import {MatTabsModule} from '@angular/material/tabs';
import {ReactiveFormsModule} from '@angular/forms';
import {MatMomentDateModule} from '@angular/material-moment-adapter';
import {MatCardModule} from '@angular/material/card';
import { MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {RouterModule, Routes} from '@angular/router';
import {EntityDataService, EntityDefinitionService, EntityMetadataMap} from '@ngrx/data';
import {compareMatch, Match} from './model/match';

import {MatchEntityService} from './services/match-entity.service';
import {MatchesResolver} from './services/matches-resolver.service';
import {MatchDataService} from './services/match-data.service';
import {TeamEntityService} from './services/team-entity.service';
import {PlayerEntityService} from "./services/player-entity.service";
import {AttendanceTimeEntityService} from "./services/attendancetime-entity.service";
import {UserEntityService} from "./services/user-entity.service";
import {TeamsResolver} from "./services/teams-resolver.service";
import {PlayersResolver} from "./services/players-resolver.service";
import {AttendanceTimesResolver} from "./services/attendancetimes-resolver.service";
import {UsersResolver} from "./services/users-resolver.service";
import {TeamDataService} from "./services/team-data.service";
import {PlayerDataService} from "./services/player-data.service";
import {UserDataService} from "./services/user-data.service";
import {AttendanceTimeDataService} from "./services/attendancetime-data.service";
import {EditTeamDialogComponent} from "./edit-team-dialog/edit-team-dialog.component";


export const matchesRoutes: Routes = [
    {
        path: '',
        component: HomeComponent,
        resolve: {
            matches: MatchesResolver
        }
    },
    {
        path: ':matchUrl',
        component: MatchComponent,
        resolve: {
            matches: MatchesResolver
        }
    }
];

const entityMetadata: EntityMetadataMap = {
    Match: {
        sortComparer: compareMatch,
        entityDispatcherOptions: {
            optimisticUpdate: true
        }
    },
    Team: {},
    User:{},
    Player:{},
    AttendanceTime:{}
};


@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatCardModule,
        MatTabsModule,
        MatInputModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatProgressSpinnerModule,
        MatSlideToggleModule,
        MatDialogModule,
        MatSelectModule,
        MatDatepickerModule,
        MatMomentDateModule,
        ReactiveFormsModule,
        RouterModule.forChild(matchesRoutes)
    ],
    declarations: [
        HomeComponent,
        MatchesCardListComponent,
        EditMatchDialogComponent,
        EditTeamDialogComponent,
        MatchComponent,

    ],
    exports: [
        HomeComponent,
        MatchesCardListComponent,
        EditMatchDialogComponent,
        MatchComponent
    ],
    providers: [
        MatchEntityService,
        TeamEntityService,
        PlayerEntityService,
        AttendanceTimeEntityService,
        UserEntityService,
        MatchesResolver,
        TeamsResolver,
        PlayersResolver,
        AttendanceTimesResolver,
        UsersResolver,
        MatchDataService,
        TeamDataService,
        PlayerDataService,
        AttendanceTimeDataService,
        UserDataService
    ]
})
export class AdminModule {

    constructor(
        private eds: EntityDefinitionService,
        private entityDataService: EntityDataService,
        private matchDataService: MatchDataService) {

        eds.registerMetadataMap(entityMetadata);

        entityDataService.registerService('Match', matchDataService);

    }


}
