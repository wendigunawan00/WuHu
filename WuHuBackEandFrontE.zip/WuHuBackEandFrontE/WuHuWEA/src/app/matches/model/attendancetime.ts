import {WeekDay} from "@angular/common";

export interface AttendanceTime {
    Id: number;
    DayInTheWeek: WeekDay;
    StartTime: Date;
    EndTime: Date;
    PlayerId: number;
}


