

export interface Team {
    Id: string;
    Name: string;
    PlayerId: number;

}


