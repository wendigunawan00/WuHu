export enum UserRole {
  Administrator = 0,
  Player = 1,
  Spectator = 2
}
