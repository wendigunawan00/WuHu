
export interface Match {
  Id: string;
  Team1Name:string;
  Team2Name:string;
  StartTime: Date;
  EndTime: Date;
  Team1Score: number;
  Team2Score: number;
  Name: string;
  Stadion: string;
  City: boolean;
}


export function compareMatch(c1:Match) {

  const compare = c1.Team1Score- c1.Team2Score;

  if (compare > 0) {
    return 1;
  }
  else if ( compare < 0) {
    return -1;
  }
  else return 0;

}
