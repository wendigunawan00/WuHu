import {UserRole} from "./userrole";


export interface User {
    Id: number;
    Email: string;
    Password: string;
    Username: number;
    Role: UserRole;
}


