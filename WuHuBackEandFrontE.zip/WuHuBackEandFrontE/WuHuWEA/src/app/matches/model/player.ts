
export interface Player {
  Id: number;
  FullName:string;
  NickName:string;
  PhotoUrl: string;
  Strength: number;
}


export function comparePlayer(c1:Player,c2:Player) {

  const compare = c1.Strength- c2.Strength;

  if (compare > 0) {
    return 1;
  }
  else if ( compare < 0) {
    return -1;
  }
  else return 0;

}
