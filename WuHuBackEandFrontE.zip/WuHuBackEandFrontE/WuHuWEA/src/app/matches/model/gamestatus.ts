export enum GameStatus {
  NOTSTARTED,
  RUNNING,
  ENDED,
  DISQUAlIFIED
}
