import {Injectable} from '@angular/core';
import {DefaultDataService, HttpUrlGenerator} from '@ngrx/data';
import {AttendanceTime} from '../model/attendancetime';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';



@Injectable()
export class AttendanceTimeDataService extends DefaultDataService<AttendanceTime> {


    constructor(http:HttpClient, httpUrlGenerator: HttpUrlGenerator) {
        super('AttendanceTime', http, httpUrlGenerator);

    }

    getAll(): Observable<AttendanceTime[]> {
        return this.http.get('/api/attendancetimes')
            .pipe(
                map(res => res["payload"])
            );
    }

}
