
import {Injectable} from "@angular/core";
import {HttpClient, HttpParams} from "@angular/common/http";
import {Observable} from "rxjs";
import {Match} from "../model/match";
import {map} from "rxjs/operators";
import {Team} from "../model/team";


@Injectable()
export class MatchesHttpService {

    constructor(private http:HttpClient) {

    }

    findAllMatches(): Observable<Match[]> {
        return this.http.get('/api/matches')
            .pipe(
                map(res => res['payload'])
            );
    }

    findMatchByUrl(matchUrl: string): Observable<Match> {
      return this.http.get<Match>(`/api/matches/${matchUrl}`);
    }

    findTeams(
        courseId:number,
        pageNumber = 0, pageSize = 3):  Observable<Team[]> {

        return this.http.get<Team[]>('/api/teams', {
            params: new HttpParams()
                .set('courseId', courseId.toString())
                .set('sortOrder', 'asc')
                .set('pageNumber', pageNumber.toString())
                .set('pageSize', pageSize.toString())
        });
    }


    saveMatches(courseId: string | number, changes: Partial<Match>) {
        return this.http.put('/api/matches/' + courseId, changes);
    }


}
