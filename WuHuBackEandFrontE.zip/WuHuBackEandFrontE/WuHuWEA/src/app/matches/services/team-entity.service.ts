import {Injectable} from '@angular/core';
import {EntityCollectionServiceBase, EntityCollectionServiceElementsFactory} from '@ngrx/data';
import {Team} from '../model/team';


@Injectable()
export class TeamEntityService extends EntityCollectionServiceBase<Team> {

    constructor(serviceElementsFactory: EntityCollectionServiceElementsFactory) {
        super("Team", serviceElementsFactory);
    }

}
