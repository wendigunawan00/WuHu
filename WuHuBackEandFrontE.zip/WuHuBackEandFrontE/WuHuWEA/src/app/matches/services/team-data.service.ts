import {Injectable} from '@angular/core';
import {DefaultDataService, HttpUrlGenerator} from '@ngrx/data';
import {Team} from '../model/team';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';



@Injectable()
export class TeamDataService extends DefaultDataService<Team> {


    constructor(http:HttpClient, httpUrlGenerator: HttpUrlGenerator) {
        super('Team', http, httpUrlGenerator);

    }

    getAll(): Observable<Team[]> {
        return this.http.get('/api/teams')
            .pipe(
                map(res => res["payload"])
            );
    }

}
