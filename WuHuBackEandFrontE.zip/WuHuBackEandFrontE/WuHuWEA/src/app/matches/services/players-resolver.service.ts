import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, Resolve, RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs';
import {PlayerEntityService} from './player-entity.service';
import {filter, first, map, tap} from 'rxjs/operators';


@Injectable()
export class PlayersResolver implements Resolve<boolean> {

    constructor(private playersService: PlayerEntityService) {

    }

    resolve(route: ActivatedRouteSnapshot,
            state: RouterStateSnapshot): Observable<boolean> {

        return this.playersService.loaded$
            .pipe(
                tap(loaded => {
                    if (!loaded) {
                       this.playersService.getAll();
                    }
                }),
                filter(loaded => !!loaded),
                first()
            );

    }

}
