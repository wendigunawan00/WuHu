import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, Resolve, RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs';
import {AttendanceTimeEntityService} from './attendancetime-entity.service';
import {filter, first, map, tap} from 'rxjs/operators';


@Injectable()
export class AttendanceTimesResolver implements Resolve<boolean> {

    constructor(private attendanceTimesService: AttendanceTimeEntityService) {

    }

    resolve(route: ActivatedRouteSnapshot,
            state: RouterStateSnapshot): Observable<boolean> {

        return this.attendanceTimesService.loaded$
            .pipe(
                tap(loaded => {
                    if (!loaded) {
                       this.attendanceTimesService.getAll();
                    }
                }),
                filter(loaded => !!loaded),
                first()
            );

    }

}
