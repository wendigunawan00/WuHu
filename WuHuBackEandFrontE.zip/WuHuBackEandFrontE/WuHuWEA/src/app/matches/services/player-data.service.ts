import {Injectable} from '@angular/core';
import {DefaultDataService, HttpUrlGenerator} from '@ngrx/data';
import {Player} from '../model/player';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';



@Injectable()
export class PlayerDataService extends DefaultDataService<Player> {


    constructor(http:HttpClient, httpUrlGenerator: HttpUrlGenerator) {
        super('Player', http, httpUrlGenerator);

    }

    getAll(): Observable<Player[]> {
        return this.http.get('/api/players')
            .pipe(
                map(res => res["payload"])
            );
    }

}
