import {Injectable} from '@angular/core';
import {DefaultDataService, HttpUrlGenerator} from '@ngrx/data';
import {Match} from '../model/match';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';



@Injectable()
export class MatchDataService extends DefaultDataService<Match> {


    constructor(http:HttpClient, httpUrlGenerator: HttpUrlGenerator) {
        super('Match', http, httpUrlGenerator);

    }

    getAll(): Observable<Match[]> {
        return this.http.get('/api/matches')
            .pipe(
                map(res => res["payload"])
            );
    }

}
