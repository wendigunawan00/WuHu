import {Injectable} from '@angular/core';
import {EntityCollectionServiceBase, EntityCollectionServiceElementsFactory} from '@ngrx/data';
import {Match} from '../model/match';


@Injectable()
export class MatchEntityService
    extends EntityCollectionServiceBase<Match> {

    constructor(
        serviceElementsFactory:
            EntityCollectionServiceElementsFactory) {

        super('Match', serviceElementsFactory);

    }

}

