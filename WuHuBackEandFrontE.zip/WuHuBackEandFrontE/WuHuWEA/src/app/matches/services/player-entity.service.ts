import {Injectable} from '@angular/core';
import {EntityCollectionServiceBase, EntityCollectionServiceElementsFactory} from '@ngrx/data';
import {Player} from '../model/player';


@Injectable()
export class PlayerEntityService extends EntityCollectionServiceBase<Player> {

    constructor(serviceElementsFactory: EntityCollectionServiceElementsFactory) {
        super("Player", serviceElementsFactory);
    }

}
