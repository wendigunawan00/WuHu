import {Injectable} from '@angular/core';
import {EntityCollectionServiceBase, EntityCollectionServiceElementsFactory} from '@ngrx/data';
import {AttendanceTime} from '../model/attendancetime';


@Injectable()
export class AttendanceTimeEntityService extends EntityCollectionServiceBase<AttendanceTime> {

    constructor(serviceElementsFactory: EntityCollectionServiceElementsFactory) {
        super("AttendanceTime", serviceElementsFactory);
    }

}
