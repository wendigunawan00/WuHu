import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, Resolve, RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs';
import {TeamEntityService} from './team-entity.service';
import {filter, first, map, tap} from 'rxjs/operators';


@Injectable()
export class TeamsResolver implements Resolve<boolean> {

    constructor(private teamsService: TeamEntityService) {

    }

    resolve(route: ActivatedRouteSnapshot,
            state: RouterStateSnapshot): Observable<boolean> {

        return this.teamsService.loaded$
            .pipe(
                tap(loaded => {
                    if (!loaded) {
                       this.teamsService.getAll();
                    }
                }),
                filter(loaded => !!loaded),
                first()
            );

    }

}
