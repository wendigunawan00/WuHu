import {ChangeDetectionStrategy, Component, OnInit} from '@angular/core';
import {Match} from '../model/match';
import {Observable} from 'rxjs';
import {defaultDialogConfig} from '../shared/default-dialog-config';
import {EditMatchDialogComponent} from '../edit-match-dialog/edit-match-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import {map} from 'rxjs/operators';
import {MatchEntityService} from '../services/match-entity.service';
import {TeamEntityService} from "../services/team-entity.service";
import {Team} from "../model/team";
import {EditTeamDialogComponent} from "../edit-team-dialog/edit-team-dialog.component";


@Component({
    selector: 'home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class HomeComponent implements OnInit {


    matches$: Observable<Match[]>;
    teams$: Observable<Team[]>;


    constructor(
      private dialog: MatDialog,
      private matchesService: MatchEntityService, private teamsService:TeamEntityService) {

    }

    ngOnInit() {
      this.reload();
    }

  reload() {
    this.matches$ = this.matchesService.entities$
    this.teams$ = this.teamsService.entities$
  }

  onAddMatch() {
    const dialogConfig = defaultDialogConfig();
    dialogConfig.data = {
      dialogTitle:"Create Match",
      mode: 'create'
    };

    this.dialog.open(EditMatchDialogComponent, dialogConfig);
  }
  onAddTeam() {
    const dialogConfig = defaultDialogConfig();
    dialogConfig.data = {
      dialogTitle:"Create Team",
      mode: 'create'
    };

    this.dialog.open(EditTeamDialogComponent, dialogConfig);
  }

}
