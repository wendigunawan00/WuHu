import {ChangeDetectionStrategy, Component, Inject} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {Match} from '../model/match';
import {UntypedFormBuilder, UntypedFormGroup, Validators} from '@angular/forms';
import {Observable} from 'rxjs';
//import {MatchesHttpService} from '../services/matches-http.service';
import {MatchEntityService} from '../services/match-entity.service';

@Component({
    selector: 'match-dialog',
    templateUrl: './edit-match-dialog.component.html',
    styleUrls: ['./edit-match-dialog.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class EditMatchDialogComponent {

    form: UntypedFormGroup;

    dialogTitle: string;

    match: Match;

    mode: 'create' | 'update';

    loading$: Observable<boolean>;

    constructor(
        private fb: UntypedFormBuilder,
        private dialogRef: MatDialogRef<EditMatchDialogComponent>,
        @Inject(MAT_DIALOG_DATA) data,
        private matchesService: MatchEntityService) {

        this.dialogTitle = data.dialogTitle;
        this.match = data.match;
        this.mode = data.mode;

        const formControls = {
            description: ['', Validators.required],
            category: ['', Validators.required],
            longDescription: ['', Validators.required],
            promo: ['', []]
        };

        if (this.mode == 'update') {
            this.form = this.fb.group(formControls);
            this.form.patchValue({...data.match});
        } else if (this.mode == 'create') {
            this.form = this.fb.group({
                ...formControls,
                url: ['', Validators.required],
                iconUrl: ['', Validators.required]
            });
        }
    }

    onClose() {
        this.dialogRef.close();
    }

    onSave() {

        const match: Match = {
            ...this.match,
            ...this.form.value
        };

        if (this.mode == 'update') {

            this.matchesService.update(match);

            this.dialogRef.close();
        } else if (this.mode == 'create') {

            this.matchesService.add(match)
                .subscribe(
                    newMatch => {

                        console.log('New Match', newMatch);

                        this.dialogRef.close();

                    }
                );

        }


    }


}
