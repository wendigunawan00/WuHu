import {AfterViewInit, ChangeDetectionStrategy, Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Match} from '../model/match';
import {Observable, of} from 'rxjs';
import {Team} from '../model/team';
import {concatMap, delay, filter, first, map, shareReplay, tap, withLatestFrom} from 'rxjs/operators';
//import {MatchesHttpService} from '../services/matchs-http.service';
import {MatchEntityService} from '../services/match-entity.service';
import {TeamEntityService} from '../services/team-entity.service';


@Component({
    selector: 'match',
    templateUrl: './match.component.html',
    styleUrls: ['./match.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MatchComponent implements OnInit {

    matches$: Observable<Match>;

    loading$: Observable<boolean>;

    teams$: Observable<Team[]>;

    displayedColumns = ['seqNo', 'description', 'duration'];

    nextPage = 0;

    constructor(
        private matchService: MatchEntityService,
        private teamsService: TeamEntityService,
        private route: ActivatedRoute) {

    }

    ngOnInit() {

        const matchUrl = this.route.snapshot.paramMap.get('matchUrl');

        this.matches$ = this.matchService.entities$
            .pipe(
                map(match => match.find(match => match.Id == matchUrl))
            );

       this.teams$ = this.teamsService.entities$
            .pipe(
                withLatestFrom(this.matches$),
                tap(([teams, match]) => {
                    if (this.nextPage == 0) {
                        this.loadMatchesPage(match);
                    }
                }),
                map(([teams, match]) =>
                    teams.filter(team => team.Name == match.Team1Name || team.Name == match.Team2Name ))
            );

        this.loading$ = this.teamsService.loading$.pipe(delay(0));

    }

    loadMatchesPage(match: Match) {
        this.teamsService.getWithQuery({
            'matchId': match.Id.toString(),
            'pageNumber': this.nextPage.toString(),
            'pageSize': '3'
        });

        this.nextPage += 1;

    }

}
