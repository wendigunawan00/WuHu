import {ChangeDetectionStrategy, Component, Inject} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {Team} from '../model/team';
import {UntypedFormBuilder, UntypedFormGroup, Validators} from '@angular/forms';
import {Observable} from 'rxjs';
//import {TeamsHttpService} from '../services/teams-http.service';
import {TeamEntityService} from '../services/team-entity.service';

@Component({
    selector: 'team-dialog',
    templateUrl: './edit-team-dialog.component.html',
    styleUrls: ['./edit-team-dialog.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class EditTeamDialogComponent {

    form: UntypedFormGroup;

    dialogTitle: string;

    team: Team;

    mode: 'create' | 'update';

    loading$: Observable<boolean>;

    constructor(
        private fb: UntypedFormBuilder,
        private dialogRef: MatDialogRef<EditTeamDialogComponent>,
        @Inject(MAT_DIALOG_DATA) data,
        private teamsService: TeamEntityService) {

        this.dialogTitle = data.dialogTitle;
        this.team = data.team;
        this.mode = data.mode;

        const formControls = {
            description: ['', Validators.required],
            category: ['', Validators.required],
            longDescription: ['', Validators.required],
            promo: ['', []]
        };

        if (this.mode == 'update') {
            this.form = this.fb.group(formControls);
            this.form.patchValue({...data.team});
        } else if (this.mode == 'create') {
            this.form = this.fb.group({
                ...formControls,
                url: ['', Validators.required],
                iconUrl: ['', Validators.required]
            });
        }
    }

    onClose() {
        this.dialogRef.close();
    }

    onSave() {

        const team: Team = {
            ...this.team,
            ...this.form.value
        };

        if (this.mode == 'update') {

            this.teamsService.update(team);

            this.dialogRef.close();
        } else if (this.mode == 'create') {

            this.teamsService.add(team)
                .subscribe(
                    newTeam => {

                        console.log('New Team', newTeam);

                        this.dialogRef.close();

                    }
                );

        }


    }


}
