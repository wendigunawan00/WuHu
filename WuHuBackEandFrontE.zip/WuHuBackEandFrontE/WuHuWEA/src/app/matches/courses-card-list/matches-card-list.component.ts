import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation} from '@angular/core';
import {Match} from "../model/match";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import {EditMatchDialogComponent} from "../edit-match-dialog/edit-match-dialog.component";
import {defaultDialogConfig} from '../shared/default-dialog-config';
import {MatchEntityService} from '../services/match-entity.service';

@Component({
    selector: 'matches-card-list',
    templateUrl: './matches-card-list.component.html',
    styleUrls: ['./matches-card-list.component.css']
})
export class MatchesCardListComponent implements OnInit {

    @Input()
    matches: Match[];

    @Output()
    matchChanged = new EventEmitter();

    constructor(
      private dialog: MatDialog,
      private matchService: MatchEntityService) {
    }

    ngOnInit() {

    }


    editMatch(match:Match) {

        const dialogConfig = defaultDialogConfig();

        dialogConfig.data = {
          dialogTitle:"Edit Match",
          match: match,
          mode: 'update'
        };

        this.dialog.open(EditMatchDialogComponent, dialogConfig)
          .afterClosed()
          .subscribe(() => this.matchChanged.emit());

    }

  onDeleteMatch(match:Match) {

        this.matchService.delete(match)
            .subscribe(
                () => console.log("Delete completed"),
                err => console.log("Deleted failed", err)
            );


  }

}









