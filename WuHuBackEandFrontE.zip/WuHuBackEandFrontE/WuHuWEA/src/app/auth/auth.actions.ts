import {createAction, props} from '@ngrx/store';
import {User} from './model/user.model';


export const login = createAction( // login = action creator
    "[Login Page] User Login", //[Login Page] = src of action
    props<{user: User}>() // properties = type of payload
);



export const logout = createAction(
  "[Top Menu] Logout"
);
