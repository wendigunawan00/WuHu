﻿namespace DataLayer.Dto;

// Player model
public class PlayerDto
{
    
    public string FullName { get; set; }
    public string NickName { get; set; }
    public string PhotoUrl { get; set; }
    public double Strength { get; set; }   

    

    public override string ToString() =>
        $"FullName:{FullName}, Nickname:{NickName}, PhotoUrl:{PhotoUrl}, Strength:{Strength})";
}


