namespace DataLayer.Dto;

// AttendanceTime class
public class PlayingTimeDto
{   
    public int MatchId { get; set; }
    public int PlayerId { get; set; }
    public TimeSpan MinuteDuration { get; set; }

    public override string ToString() =>
        $"Match:{MatchId}, Player:{PlayerId}, MinuteDuration:{MinuteDuration})";
}


