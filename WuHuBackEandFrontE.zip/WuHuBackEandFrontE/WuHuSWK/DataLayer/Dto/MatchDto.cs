﻿using DataLayer.Domain;

namespace DataLayer.Dto;

// Match model
public class MatchDto
{   
    public string Team1Name { get; set; }
    public string Team2Name { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public int? Team1Score { get; set; }
    public int? Team2Score { get; set; }
    public string? Name { get; set; }
    public string? Stadion { get; set; }
    public string? City { get; set; }
    public GameStatus Status { get; set; }

    

    public override string ToString() =>
        $"Team1Id:{Team1Name}, Team2Id:{Team2Name}, StartTime:{StartTime}, Team1Score:{Team1Score}, Team2Score:{Team2Score}, Name:{Name}, Location:{Stadion}, City:{City})";
}

    

