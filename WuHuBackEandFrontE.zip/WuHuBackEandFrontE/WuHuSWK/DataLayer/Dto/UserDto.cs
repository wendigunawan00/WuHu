﻿using DataLayer.Domain;

namespace DataLayer.Dto;

public class UserDto
{
    public string Email { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    public UserRole Role { get; set; }

    
    public override string ToString() =>
        $"Email:{Email}, Username:{Username}, Role:{Role})";
}
