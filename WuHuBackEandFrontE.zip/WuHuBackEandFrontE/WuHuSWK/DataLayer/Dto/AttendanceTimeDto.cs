namespace DataLayer.Dto;

// AttendanceTime class
public class AttendanceTimeDto
{   
    public int Player { get; set; }
    public DayOfWeek DayInTheWeek { get; set; }
    public TimeOnly StartTime { get; set; }
    public TimeOnly EndTime { get; set; }

    public override string ToString() =>
         $"Match:{DayInTheWeek}, Player:{Player}, StartTime:{StartTime} EndTime:{EndTime})";
}


