﻿namespace DataLayer.Dto;

// TeamDto model
public class TeamDto
{
    public string Name { get; set; }
    public int PlayerId { get; set; }

    

    public override string ToString() =>
        $"Team(Name:{Name},Player:{PlayerId}))";
}
