﻿namespace DataLayer.Domain;

// AttendanceTime class
public class PlayingTime
{
    public PlayingTime(int id, int match_id, int player_id, TimeSpan minute_duration)
    {
        Id = id;
        MatchId = match_id;
        PlayerId = player_id;
        MinuteDuration = minute_duration;
    }

    public int Id { get; set; }
    public int MatchId { get; set; }
    public int PlayerId { get; set; }
    public TimeSpan MinuteDuration { get; set; }

    public override string ToString() =>
        $"PlayingTime(Id:{Id}, Match:{MatchId}, Player:{PlayerId}, MinuteDuration:{MinuteDuration})";
}

