﻿
namespace DataLayer.Domain;

public enum GameStatus
{
    NOTSTARTED,
    RUNNING,
    ENDED,
    DISQUAlIFIED
}
