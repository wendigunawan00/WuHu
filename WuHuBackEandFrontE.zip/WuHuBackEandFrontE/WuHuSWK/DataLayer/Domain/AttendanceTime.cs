﻿namespace DataLayer.Domain;

// AttendanceTime class
public class AttendanceTime
{
    public AttendanceTime(string id,DayOfWeek days_of_week, TimeOnly start_time, TimeOnly end_time, int player_id)
    {
        Id = id;
        DayInTheWeek = days_of_week;
        StartTime = start_time;
        EndTime = end_time;
        PlayerId = player_id; 
        
    }
    

    public string Id { get; set; }
    public DayOfWeek DayInTheWeek { get; set; }
    public TimeOnly StartTime { get; set; }
    public TimeOnly EndTime { get; set; }
    public int PlayerId { get; set; }

    public override string ToString() =>
        $"Match:{DayInTheWeek}, Player:{PlayerId}, StartTime:{StartTime} EndTime:{EndTime})";
}

