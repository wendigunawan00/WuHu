﻿namespace DataLayer.Domain;

// Team model
public class Team
{
    public string Id { get; set; }
    public string Name { get; set; }
    public int PlayerId { get; set; }

    public Team(string id, string name, int player_id)
    {
        Id = id;
        Name = name;
        PlayerId = player_id;
    }

    public override string ToString() =>
        $"Team(Id:{Id}, Name:{Name},Player:{PlayerId}))";    
}


