﻿using System.ComponentModel.DataAnnotations;

namespace DataLayer.Domain;

public class User
{
    public int Id { get; set; }
    public string Email { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    [EnumDataType(typeof(UserRole))]
    public UserRole Role { get; set; }

    public User(int id, string email, string username, string password, UserRole role)
    {
        Id = id;
        Email = email;
        Username = username;
        Password = password;
        Role = role;
    }
    public override string ToString() =>
        $"User(Id:{Id}, Email:{Email}, Username:{Username}, Role:{Role})";
}
