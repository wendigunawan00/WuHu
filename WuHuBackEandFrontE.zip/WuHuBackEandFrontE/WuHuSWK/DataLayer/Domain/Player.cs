﻿namespace DataLayer.Domain;

// Player model
public class Player
{
    public int Id { get; set; }
    public string FullName { get; set; }
    public string NickName { get; set; }
    public string PhotoUrl { get; set; }
    public double Strength { get; set; }
    public ISet<AttendanceTime> AttendanceTimes;

    public Player(int id, string full_name, string nick_name, string photo_url, double strength)
    {
        Id = id;
        FullName = full_name;
        NickName = nick_name;
        PhotoUrl = photo_url;
        Strength = strength;
        AttendanceTimes = new HashSet<AttendanceTime>();
    }       

    public override string ToString() =>
      $"Player(id:{Id}, FullName:{FullName}, Nickname:{NickName}, PhotoUrl:{PhotoUrl}, Strength:{Strength})";

    public ISet<AttendanceTime> GenerateStrictAttendanceTimes(int frequency)
    {
        var random = new Random();

        for (int i = 0; i < frequency; i++)
        {
            var day = (DayOfWeek)random.Next(1, 8);
            var startHour = random.Next(8, 17);
            var endHour = random.Next(17,22);
            var startMinute = random.Next(0, 60);
            var endMinute = random.Next(0, 60);

            var startTime = new TimeOnly( startHour, startMinute, 0);
            var endTime = new TimeOnly(endHour, endMinute, 0);

            var attendanceTime = new AttendanceTime($"At-{Id}-{i + 1}", day, startTime, endTime, Id);
            AttendanceTimes.Add(attendanceTime);
        }

        return AttendanceTimes;
    }

    public ISet<AttendanceTime> GenerateStandardAttendanceTimes(int frequency)
    {
        var random = new Random();

        for (int i = 0; i < frequency; i++)
        {
            var day = (DayOfWeek)random.Next(1, 8);
            var startHour = random.Next(8, 14); // limit start hour to 8 - 10
            var endHour = startHour + random.Next(2, 8); // limit end hour t 22:00 after start
            if (endHour > 22) endHour = 20; // limit end hour to 21pm
           

            var startTime = new TimeOnly( startHour, 0, 0);
            var endTime = new TimeOnly( endHour, 0, 0);

            var attendanceTime = new AttendanceTime($"At-{Id}-{i + 1}", day, startTime, endTime, Id);
            AttendanceTimes.Add(attendanceTime);
        }

        return AttendanceTimes;
    }
       
    public ISet<AttendanceTime> GenerateAttendanceTimesByDays(int frequency)
    {
        var random = new Random();
        if (frequency > 7)
            frequency = 7;

        var daysOfWeek = new HashSet<DayOfWeek>(); // create a set to track distinct days

        while (daysOfWeek.Count < frequency) // loop until we have added the desired number of distinct days
        {
            var day = (DayOfWeek)random.Next(1, 8);
            daysOfWeek.Add(day); // add the day to the set
        }

        foreach (var day in daysOfWeek)
        {
            var startTime = new TimeOnly(8, 0, 0);
            var endTime = new TimeOnly(22, 0, 0);

            var attendanceTime = new AttendanceTime($"At-{Id}-{day}", day, startTime, endTime, Id);
            AttendanceTimes.Add(attendanceTime);
        }

        return AttendanceTimes;
    }

    public bool CanPlayInMatch(DateTime dateTime)
    {
        // Filter the attendance times by day of the week
        var matchingAttendanceTimes = AttendanceTimes.Any(a => a.DayInTheWeek == dateTime.DayOfWeek);

        // Check if the current time falls between the start and end times of any of the matching attendance times
        //var r = matchingAttendanceTimes.Any(a => dateTime.TimeOfDay >= a.StartTime.ToTimeSpan() && dateTime.TimeOfDay <= a.EndTime.ToTimeSpan());
        return matchingAttendanceTimes;
    }

     /*public bool CanPlayInMatch(DateTime dateTime)
     {
         var foundMatch = false;

         Parallel.ForEach(AttendanceTimes, attendanceTime =>
         {
             // check if the day matches
             if (dateTime.DayOfWeek == attendanceTime.DayInTheWeek)
             {
                 // Check if the match start time is between the start and end time of the attendance time
                 if (dateTime.TimeOfDay.CompareTo(attendanceTime.StartTime.ToTimeSpan()) >= 0 && dateTime.TimeOfDay.CompareTo(attendanceTime.EndTime.ToTimeSpan()) <= 0)
                 {
                     foundMatch = true;
                 }
             }
         });

         return foundMatch;
     }*/
        

    public async Task<bool> CanPlayInMatchAsync(DateTime dateTime)
    {
        var foundMatch = false;

        await Task.Run(() =>
        {
            Parallel.ForEach(AttendanceTimes, attendanceTime =>
            {
                // check if the day matches
                if (dateTime.DayOfWeek == attendanceTime.DayInTheWeek)
                {
                    // Check if the match start time is between the start and end time of the attendance time
                    if (dateTime.TimeOfDay.CompareTo(attendanceTime.StartTime.ToTimeSpan()) >= 0 && dateTime.TimeOfDay.CompareTo(attendanceTime.EndTime.ToTimeSpan()) <= 0)
                    {
                        foundMatch = true;
                    }
                }
            });
        });

        return foundMatch;
    }


    /*public bool CanPlayInMatch(DateTime dateTime) 
    {
        foreach (var attendanceTime in AttendanceTimes)
        {
            // check if the day matches
            if (dateTime.DayOfWeek == attendanceTime.DayInTheWeek)
            {
                var boolDateTime = attendanceTime.DayInTheWeek;
                // Check if the match start time is between the start and end time of the attendance time
                //if (dateTime >= attendanceTime.StartTime && dateTime.TimeOfDay <= attendanceTime.EndTime)
                var dTd = dateTime.TimeOfDay;
                var aST = attendanceTime.StartTime;
                var aSTTS = attendanceTime.StartTime.ToTimeSpan();
                var aETTS = attendanceTime.EndTime.ToTimeSpan();
                var x = aETTS;
                if (dateTime.TimeOfDay.CompareTo(attendanceTime.StartTime.ToTimeSpan()) >= 0 && dateTime.TimeOfDay.CompareTo(attendanceTime.EndTime.ToTimeSpan()) <= 0)
                {
                    

                    return true;
                }
            }
        }
        //return true;
        return false;
    }*/
}

