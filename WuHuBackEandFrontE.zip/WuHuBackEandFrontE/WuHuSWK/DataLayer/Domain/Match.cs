﻿namespace DataLayer.Domain;

// Match model
public class Match
{
    private const int PLAYER_NUMBER = 11;
    private const double DEFAULT_STRENGTH = 1500;
    public string Id { get; set; }    
    public string Team1Name { get; set; }
    public string Team2Name { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public int? Team1Score { get; set; }
    public int? Team2Score { get; set; }
    public string? Name { get; set; }
    public string? Stadion { get; set; }
    public string? City { get; set; }
    public GameStatus Status { get; set; }

    public Match() { }

    public Match(string id, string team1_name, string team2_name, DateTime start_time, DateTime end_time, int? team1_score, int? team2_score)
    {
        Id = id;
        Team1Name = team1_name;
        Team2Name = team2_name;
        StartTime = start_time;
        EndTime = end_time;
        Team1Score = team1_score;
        Team2Score = team2_score;
    }

    public Match(string id,string team1_name, string team2_name, DateTime start_time, DateTime end_time, int? team1_score, int? team2_score, string name, string stadion, string city,GameStatus status)
    {
        Team1Name = team1_name;
        Team2Name = team2_name;
        StartTime = start_time;
        EndTime = end_time;
        Team1Score = team1_score;
        Team2Score = team2_score;
        Name = name;
        Stadion = stadion;
        City = city;
        Status = status;
    }

    public override string ToString() =>
      $"Match(id:{Id}, Team1Id:{Team1Name}, Team2Id:{Team2Name}, MatchTime:{StartTime}, Team1Score:{Team1Score}, Team2Score:{Team2Score})";

    public double CalculateTeamStrength(List<Player> team1Players, List<Player> team2Players)
    {
        double team1Strength = team1Players.Sum(p => p?.Strength ?? 0);
        double team2Strength = team2Players.Sum(p => p?.Strength ?? 0);

        double teamStrengthDiff = Math.Abs(team1Strength - team2Strength);
        bool team1Stronger = team1Strength > team2Strength;
        bool team2Stronger = team2Strength > team1Strength;

        // Check if either team is stronger/weaker than the other by a margin of 200 points
        if (teamStrengthDiff >= 200)
        {
            if (team1Stronger && Team1Score > Team2Score)
            {
                return team1Strength * 1.3;
            }
            else if (team1Stronger && Team1Score < Team2Score)
            {
                return team1Strength * 0.9;
            }
            else if (team2Stronger && Team2Score > Team1Score)
            {
                return team2Strength * 1.3;
            }
            else if (team2Stronger && Team2Score < Team1Score)
            {
                return team2Strength * 0.9;
            }
        }
        else
        {
            if (team1Stronger && Team1Score > Team2Score)
            {
                return team1Strength * 1.15;
            }
            else if (team1Stronger && Team1Score < Team2Score)
            {
                return team1Strength * 0.7;
            }
            else if (team2Stronger && Team2Score > Team1Score)
            {
                return team2Strength * 1.15;
            }
            else if (team2Stronger && Team2Score < Team1Score)
            {
                return team2Strength * 0.7;
            }
        }

        // If none of the above conditions are met, return the default team strength
        return PLAYER_NUMBER *DEFAULT_STRENGTH;
    }
       

    public List<Player> UpdateTeamStrengths(IList<Player> team1Players, IList<Player> team2Players, int? team1Score = null, int? team2Score = null)
    {
        // Calculate the total strength of each team
        double team1Strength = team1Players.Sum(p => p?.Strength ?? 0);
        double team2Strength = team2Players.Sum(p => p?.Strength ?? 0);

        // Determine which team is stronger
        bool team1Stronger = team1Strength > team2Strength;
        bool team2Stronger = team2Strength > team1Strength;

        // Determine the margin of victory (if applicable)
        int marginOfVictory = Math.Abs(team1Score.GetValueOrDefault() - team2Score.GetValueOrDefault());

        // Create a new list of players with updated strengths for Team 1
        List<Player> updatedTeam1Players = new List<Player>();
        foreach (var player in team1Players)
        {
            double updatedStrength = player.Strength;

            if (team1Stronger && team1Score > team2Score)
            {
                updatedStrength *= 1.3;
            }
            else if (team1Stronger && team1Score < team2Score)
            {
                updatedStrength *= 0.9;
            }
            else if (team2Stronger && team2Score > team1Score)
            {
                updatedStrength *= 1.15;
            }
            else if (team2Stronger && team2Score < team1Score)
            {
                updatedStrength *= 0.7;
            }
            player.Strength = updatedStrength;

            updatedTeam1Players.Add(player);
        }

        // Create a new list of players with updated strengths for Team 2
        List<Player> updatedTeam2Players = new List<Player>();
        foreach (var player in team2Players)
        {
            double updatedStrength = player.Strength;

            if (team2Stronger && team2Score > team1Score)
            {
                updatedStrength *= 1.3;
            }
            else if (team2Stronger && team2Score < team1Score)
            {
                updatedStrength *= 0.9;
            }
            else if (team1Stronger && team1Score > team2Score)
            {
                updatedStrength *= 1.15;
            }
            else if (team1Stronger && team1Score < team2Score)
            {
                updatedStrength *= 0.7;
            }
            player.Strength = updatedStrength;

            updatedTeam2Players.Add(player);
        }

        // Combine the two lists and return the result
        return updatedTeam1Players.Concat(updatedTeam2Players).ToList();
    }


}



