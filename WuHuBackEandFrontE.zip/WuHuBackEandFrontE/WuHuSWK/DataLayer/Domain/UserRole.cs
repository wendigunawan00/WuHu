﻿namespace DataLayer.Domain;

// User roles
public enum UserRole
{
    Administrator,
    Player,
    Spectator
}
