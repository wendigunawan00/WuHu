﻿using DataLayer.Domain;
using System;
using static Azure.Core.HttpHeader;
using System.Collections.Generic;

namespace DataLayer.DataGenerator
{
    public class DataGenerator
    {
        private static ISet<int> usedIds = new HashSet<int>();
        private static readonly Random random = new Random();

        private static ISet<string> usedFullNames = new HashSet<string>();
    
        public static readonly List<DateTime> START_TIMES = new List<DateTime>(){
            new DateTime(2023, 5, 1, 10, 0, 0), new DateTime(2023, 5, 11, 12, 30,0), new DateTime(2023, 5, 14, 14, 0, 0),  new DateTime(2023, 4, 21, 16, 0, 0),
            new DateTime(2023, 5, 2, 18, 0, 0), new DateTime(2023, 5, 12, 9, 30, 0), new DateTime(2023, 5, 15, 13, 0, 0),  new DateTime(2023, 4, 22, 15, 0, 0),
            new DateTime(2023, 5, 3, 11, 0, 0), new DateTime(2023, 5, 13, 19, 0, 0), new DateTime(2023, 5, 16, 14, 30, 0), new DateTime(2023, 4, 23, 17, 0, 0),
            new DateTime(2023, 5, 27, 11, 0, 0), new DateTime(2023, 5, 23, 19, 0, 0), new DateTime(2023, 5, 26, 14, 30, 0), new DateTime(2023, 4, 29, 17, 0, 0),
            new DateTime(2023, 4, 24, 12, 0, 0), new DateTime(2023, 4, 25, 19, 0, 0), new DateTime(2023, 4, 26, 14, 30, 0), new DateTime(2023, 4, 30, 17, 0, 0),
            new DateTime(2023, 5, 24, 12, 0, 0), new DateTime(2023, 5, 25, 19, 0, 0), new DateTime(2023, 5, 26, 14, 30, 0), new DateTime(2023, 5, 30, 17, 0, 0),
            new DateTime(2023, 5, 4, 10, 0, 0), new DateTime(2023, 5, 14, 12, 0, 0), new DateTime(2023, 5, 17, 15, 30, 0),
        }; 
        /*public static readonly List<DateTime> START_TIMES = new List<DateTime>(){
            new DateTime(1, 1, 1, 10, 0, 0), new DateTime(1, 1, 1, 12, 30,0), new DateTime(1, 1, 1, 14, 0, 0),  new DateTime(1, 1, 1, 16, 0, 0),
            new DateTime(1, 1, 2, 18, 0, 0), new DateTime(1, 1, 1, 9, 30, 0), new DateTime(1, 1, 1, 13, 0, 0),  new DateTime(1, 1, 1, 15, 0, 0),
            
        };*/

        public static readonly List<string> TEAM_NAMES = new List<string> {
        "Crimson Tide","Golden Eagles","Huskies","Wildcats", "Panthers","Thunderbirds","Rams", "Tigers", "Bulldogs","Hornets", "Warriors","Lions", "Mustangs","Eagles",
         "Sharks","Wolves","Falcons","Bears","Pirates","Dragons","Thunderbolts","Firebirds", "Stealth Tigers","Avalanche","Mavericks","Hurricane Hawks","Red Phoenixes"        
         };

        public static readonly List<string> TEAM_NAMES_2 = new List<string> {
        "Lightning Bolts", "Crimson Dragons","Blue Cobras", "Golden Eagles","Iron Titans","Sky Warriors","Shadow Panthers","Black Knights","Green Hornets",
        "Silver Wolves","Neon Jaguars","Sapphire Serpents","Platinum Penguins","Fire Dragons","Storm Warriors","Ice Titan"
        };
        private static readonly List<string> FIRST_NAMES = new List<string>(new string[] {
         "Emily", "Emma", "Olivia", "Ava", "Sophia", "Isabella", "Mia", "Charlotte", "Amelia", "Harper", "Evelyn", "Abigail", "Ella", "Elizabeth", "Sofia", "Madison",
         "Avery", "Eleanor", "Grace", "Hannah", "Chloe", "Camila", "Bogdan" });

        private static readonly List<string> LAST_NAMES = new List<string>(new string[] {
        "Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson","Moore", "Taylor", "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin",
        "Thompson", "Garcia", "Martinez", "Robinson", "Clark", "Rodriguez","Burlacu"
        });

        public static DateTime PickRandomStartTime()
        {
            Random random = new Random();
            int index = random.Next(0, START_TIMES.Count);
            return START_TIMES[index];
        }

        public static DateTime CalculateEndTime(DateTime startTime)
        {
            return startTime.AddHours(1.5);
        }

        public int GetRandomNumber()
        {
            Random random = new Random();
            return random.Next(8);
        }

        private static int GenerateUniqueId()
        {
            int id;
            do
            {
                id = random.Next(1000, 10000);
            } while (usedIds.Contains(id));
            usedIds.Add(id);
            return id;
        }

        public static (User user, Player? player) GenerateUserAndPlayer()
        {
            string firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
            string lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
            string fullName = $"{firstName} {lastName}";
            UserRole temprole = (UserRole)random.Next(3); // randomly select UserRole
            string email = $"{firstName.ToLower()}.{lastName.ToLower()}@example.com"; // generate email using GenerateEmailAddress method

            // generate User object
            User user = new User(
                id: GenerateUniqueId(),
                email: email,
                username: email,
                password: $"P{FIRST_NAMES[random.Next(FIRST_NAMES.Count)]}{LAST_NAMES[random.Next(LAST_NAMES.Count)]}123",
                role: temprole
            );

            Player player = null;

            // generate Player object if role is Player
            if (temprole == UserRole.Player)
            {
                string photoUrl = $"resource/photourl/{firstName}-{lastName}";
                double strength = random.NextDouble() * (100 - 30) + 30; // generate random strength between 30 and 100
                player = new Player(
                    id: user.Id,
                    full_name: fullName,
                    nick_name: firstName,
                    photo_url: photoUrl,
                    strength: strength
                );
            }

            return (user, player);
        }


        public static List<(User user, Player? player)> GenerateUsersAndPlayersWithMaximalUserCount(int count)
        {
            var usersAndPlayers = new List<(User user, Player? player)>();

            for (int i = 0; i < count; i++)
            {
                string firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
                string lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
                string fullName = $"{firstName} {lastName}";

                // Keep generating new first last names until we get a unique full name
                while (usedFullNames.Contains(fullName)) 
                {
                    firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
                    lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
                    fullName = $"{firstName} {lastName}";
                }

                usedFullNames.Add(fullName);
                UserRole role = (UserRole)random.Next(3);
                string email = $"{firstName.ToLower()}.{lastName.ToLower()}@example.com";

                User user = new User(
                    id: GenerateUniqueId(),
                    email: email,
                    username: email,
                    password: $"P{FIRST_NAMES[random.Next(FIRST_NAMES.Count)]}{LAST_NAMES[random.Next(LAST_NAMES.Count)]}123",
                    role: role
                );

                Player? player = null;
                if (role == UserRole.Player)
                {
                    string photoUrl = $"resource/photourl/{firstName}-{lastName}";
                    double strength = random.NextDouble() * (100 - 30) + 30;
                    player = new Player(
                        id: user.Id,
                        full_name: fullName,
                        nick_name: firstName,
                        photo_url: photoUrl,
                        strength: strength
                    );
                }

                usersAndPlayers.Add((user, player));
            }

            return usersAndPlayers;
        }

        public static List<(User user, Player? player)> GenerateUsersAndPlayersWithExactPlayerCount(int playerCount)
        {
            var usersAndPlayers = new List<(User user, Player? player)>();

            int totalPlayers = 0;
            while (totalPlayers < playerCount)
            {
                string firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
                string lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
                string fullName = $"{firstName} {lastName}";

                // Keep generating new first last names until we get a unique full name
                while (usedFullNames.Contains(fullName))
                {
                    firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
                    lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
                    fullName = $"{firstName} {lastName}";
                }

                usedFullNames.Add(fullName);
                UserRole role = (totalPlayers < playerCount) ? UserRole.Player : (UserRole)random.Next(3);
                string email = $"{firstName.ToLower()}.{lastName.ToLower()}@example.com";

                User user = new User(
                    id: GenerateUniqueId(),
                    email: email,
                    username: email,
                    password: $"P{FIRST_NAMES[random.Next(FIRST_NAMES.Count)]}{LAST_NAMES[random.Next(LAST_NAMES.Count)]}123",
                    role: role
                );

                Player? player = null;
                if (role == UserRole.Player)
                {
                    string photoUrl = $"resource/photourl/{firstName}-{lastName}";
                    double strength = random.NextDouble() * (100 - 30) + 30;
                    player = new Player(
                        id: user.Id,
                        full_name: fullName,
                        nick_name: firstName,
                        photo_url: photoUrl,
                        strength: strength
                    );
                    totalPlayers++;
                }

                usersAndPlayers.Add((user, player));
            }

            return usersAndPlayers;
        }

        public static List<(User user, Player? player)> GenerateUsersAndPlayersWithMinimumPlayerCount(int count)
        {
            var usersAndPlayers = new List<(User user, Player? player)>();

            int playerCount = 0;
            while (usersAndPlayers.Count < count)
            {
                string firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
                string lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
                string fullName = $"{firstName} {lastName}";

                // Keep generating new first last names until we get a unique full name
                while (usedFullNames.Contains(fullName))
                {
                    firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
                    lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
                    fullName = $"{firstName} {lastName}";
                }

                usedFullNames.Add(fullName);
                UserRole role = (UserRole)random.Next(3);
                string email = $"{firstName.ToLower()}.{lastName.ToLower()}@example.com";

                User user = new User(
                    id: GenerateUniqueId(),
                    email: email,
                    username: email,
                    password: $"P{FIRST_NAMES[random.Next(FIRST_NAMES.Count)]}{LAST_NAMES[random.Next(LAST_NAMES.Count)]}123",
                    role: role
                );

                Player? player = null;
                if (role == UserRole.Player)
                {
                    string photoUrl = $"resource/photourl/{firstName}-{lastName}";
                    double strength = random.NextDouble() * (100 - 30) + 30;
                    player = new Player(
                        id: user.Id,
                        full_name: fullName,
                        nick_name: firstName,
                        photo_url: photoUrl,
                        strength: strength
                    );
                    playerCount++;
                }

                usersAndPlayers.Add((user, player));
            }

            // Ensure that we have exactly `count` number of players
            if (playerCount < count)
            {
                for (int i = 0; i < count - playerCount; i++)
                {
                    string firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
                    string lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
                    string fullName = $"{firstName} {lastName}";

                    // Keep generating new first last names until we get a unique full name
                    while (usedFullNames.Contains(fullName))
                    {
                        firstName = FIRST_NAMES[random.Next(FIRST_NAMES.Count)];
                        lastName = LAST_NAMES[random.Next(LAST_NAMES.Count)];
                        fullName = $"{firstName} {lastName}";
                    }

                    usedFullNames.Add(fullName);

                    string email = $"{firstName.ToLower()}.{lastName.ToLower()}@example.com";

                    User user = new User(
                        id: GenerateUniqueId(),
                        email: email,
                        username: email,
                        password: $"P{FIRST_NAMES[random.Next(FIRST_NAMES.Count)]}{LAST_NAMES[random.Next(LAST_NAMES.Count)]}123",
                        role: UserRole.Player
                    );

                    string photoUrl = $"resource/photourl/{firstName}-{lastName}";
                    double strength = random.NextDouble() * (100 - 30) + 30;
                    Player player = new Player(
                        id: user.Id,
                        full_name: fullName,
                        nick_name: firstName,
                        photo_url: photoUrl,
                        strength: strength
                    );

                    usersAndPlayers.Add((user, player));
                }
            }

            return usersAndPlayers;
        }



    }
}
