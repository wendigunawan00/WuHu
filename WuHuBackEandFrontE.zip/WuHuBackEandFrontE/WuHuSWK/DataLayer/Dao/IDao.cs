﻿namespace DataLayer.Dao
{
    public interface IDao
    {
    }
}
