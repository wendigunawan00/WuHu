﻿using DataLayer.Domain;
using InfrastructureLayer.Common;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using static DataLayer.Dao.DaoImpl.AdoMapDao;

namespace DataLayer.Dao.DaoImpl;


public class AdoGenericDao<T> : IGenericDao<T>
{
    protected readonly AdoTemplate template;


    Dictionary<Type, Delegate> domainMapperDict = new Dictionary<Type, Delegate>{
        { typeof(User), (RowMapper<User>) (row => MapRowToUser(row))},
        { typeof(Player), (RowMapper<Player>) (row => MapRowToPlayer(row)) },
        { typeof(Match), (RowMapper<Match>) (row => MapRowToMatch(row)) },
        { typeof(AttendanceTime), (RowMapper<AttendanceTime>) (row => MapRowToAttendanceTime(row)) },
        { typeof(PlayingTime), (RowMapper<PlayingTime>) (row => MapRowToPlayingTime(row)) },
        { typeof(Team), (RowMapper<Team>) (row => MapRowToTeam(row)) }
 
    };

    Dictionary<Type, string> domainIdDict = new Dictionary<Type, string>{
        { typeof(User), "id" },
        { typeof(Player), "id" },
        { typeof(Match), "id" },
        { typeof(PlayingTime), "id"},
        { typeof(Team), "id"}
    };

    public AdoGenericDao(IConnectionFactory connectionFactory)
    {
        template = Util.createAdoTemplate(connectionFactory) ?? throw new ArgumentNullException(nameof(connectionFactory));
        // not recommended
        //this.template = new AdoTemplate(connectionFactory);
    }

    public async Task<IEnumerable<T>> FindAllAsync(string table)
    {
        Delegate domainMapper;
        if (domainMapperDict.TryGetValue(typeof(T), out domainMapper))
        {
            var MapRowToT = (RowMapper<T>)domainMapper;
            var x= await template.QueryAsync(@$"select * from {table}", MapRowToT);
            return x;
        }
        return Enumerable.Empty<T>();
    }

    public async Task<int> CountAllElements(string table)
    {
        return await template.ExecuteCountAsync(@$"select count(*) from {table}");
    }

    public async Task<T?> FindByIdAsync(object id, string table)
    {
        Delegate domainMapper;
        string domainId;
        if (domainMapperDict.TryGetValue(typeof(T), out domainMapper) &&
            domainIdDict.TryGetValue(typeof(T), out domainId))
        {
            var MapRowToT = (RowMapper<T>)domainMapper;

            return await template.QuerySingleAsync(@$"select * from {table} where {domainId}=@id",
            MapRowToT,
            new QueryParameter("@id", id));
        }
        return default;
    }

    public async Task<T?> FindLastAsync(string table)
    {
        Delegate domainMapper;
        string domainId;
        if (domainMapperDict.TryGetValue(typeof(T), out domainMapper) &&
            domainIdDict.TryGetValue(typeof(T), out domainId))
        {
            var MapRowToT = (RowMapper<T>)domainMapper;
            return await template.QuerySingleAsync(@$"select * from {table} where {domainId}=(SELECT max({domainId}) FROM {table})"
                , MapRowToT);
        }
        return default;
    }

    public async Task<IEnumerable<T?>> FindTByProperties(Dictionary<string, object> properties, string sql)
    {
        Delegate domainMapper;
        if (domainMapperDict.TryGetValue(typeof(T), out domainMapper))
        {
            var MapRowToT = (RowMapper<T>)domainMapper;
            var queryParameters = properties.Select(c => new QueryParameter($"@{c.Key}", c.Value)).ToArray();
            return await template.QueryAsync<T>(@sql, MapRowToT, queryParameters);
        }
        return Enumerable.Empty<T>();
    }

    public async Task<IEnumerable<T>> FindTByAnyCriteria(IDictionary<string, object> criteria, string tableName)
    {
        var sql = $"SELECT * FROM {tableName}";
        if (criteria != null && criteria.Any())
        {
            sql += " WHERE ";
            var whereClauses = criteria.Select(kv => $"{kv.Key}=@{kv.Key}");
            sql += string.Join(" AND ", whereClauses);
        }

        var parameters = criteria?.Select(kv => new QueryParameter($"@{kv.Key}", kv.Value)).ToArray() ?? new QueryParameter[0];

        return await template.QueryAsync<T>(sql, reader =>
        {
            var props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            var values = new object[props.Length];
            for (int i = 0; i < props.Length; i++)
            {
                values[i] = reader.GetValue(reader.GetOrdinal(props[i].Name));
            }
            return (T)Activator.CreateInstance(typeof(T), values);
        }, parameters);
    }


    public async Task<int> CountTWhereProperties(IDictionary<string, object> properties, string table)
    {
        string sql = $"SELECT COUNT(*) FROM {table} WHERE ";
        int count = 0;
        foreach (var kvp in properties)
        {
            if (count > 0) sql += " AND ";
            sql += $"{kvp.Key} = @{kvp.Key}";
            count++; 
        }
        //var f = properties.Select(p => new QueryParameter($"@{p.Key}", p.Value)).ToArray();
        var result = await template.ExecuteCountAsync(@sql, properties.Select(p => new QueryParameter($"@{p.Key}", p.Value)).ToArray());
        return result;
    }


    public async Task<bool> DeleteByIdAsync(object id, string table)
    {
        T? c = await FindByIdAsync(id, table);
        if (c is not null)
        {
            string sqlcmd = $"delete from {table} where id=@id";
            return await template.ExecuteAsync(@sqlcmd,
                   new QueryParameter("@id", id)) == 1;
        }
        return false;
    }
       

    public async Task<bool> UpdateAsync(T entity, string table)
    {
        PropertyInfo[] properties = typeof(T).GetProperties();
        string primaryKeyColumnName = "id";
        PropertyInfo primaryKeyProperty = properties.FirstOrDefault(p => p.Name == primaryKeyColumnName);

        if (primaryKeyProperty is not null)
        {
            string primaryKeyValue = primaryKeyProperty.GetValue(entity).ToString();
            string updateSql = $"UPDATE {table} SET ";

            List<QueryParameter> parameters = new List<QueryParameter>();

            foreach (PropertyInfo property in properties)
            {
                if (property != primaryKeyProperty)
                {
                    updateSql += $"{property.Name} = @{property.Name}, ";
                    parameters.Add(new QueryParameter($"@{property.Name}", property.GetValue(entity)));
                }
            }

            // Remove the last ", " characters from the SQL string
            updateSql = updateSql.Remove(updateSql.Length - 2);

            updateSql += $" WHERE {primaryKeyColumnName} = @{primaryKeyColumnName}";
            parameters.Add(new QueryParameter($"@{primaryKeyColumnName}", primaryKeyValue));

            int rowsAffected = await template.ExecuteAsync(updateSql, parameters.ToArray());

            return rowsAffected == 1;
        }

        return false;
    }

    public async Task<bool> StoreAsync(T entity, string table) { 
        
        var properties = typeof(T).GetProperties().Where(p => p.CanRead);
        var primaryKey = properties.FirstOrDefault(p => p.CustomAttributes.Any(attr => attr.AttributeType == typeof(KeyAttribute)));

        
        var parameters = properties.Select(p => new QueryParameter($"@{p.Name}", p.GetValue(entity))).ToArray();
        var entityParameters = properties.Select(p => new QueryParameter($"@{p.Name}", p.GetValue(entity))).ToArray();
       
        var primKey = entityParameters[0].Name.Substring(1);
        var existsSql = $"select count(*) from {table} where {primKey} = {entityParameters[0].Name}";
        var exists = await template.ExecuteCountAsync(existsSql, new QueryParameter(entityParameters[0].Name, entityParameters[0].Value));
        //if (entityParameters[0].Value is not null || primaryKey != null && primaryKey.GetValue(entity) != null)
        if (exists>0)
        {
            return await UpdateAsync(entity, table);
        }
        else
        {
            var insertSql = $"insert into {table} ({string.Join(", ", properties.Select(p => p.Name))}) values ({string.Join(", ", properties.Select(p => $"@{p.Name}"))})";
            return await template.ExecuteAsync(insertSql, parameters) == 1;
        }
       
    }

    public async Task<bool> StoreAllAsync(IEnumerable<T> entities, string table)
    {
        var properties = typeof(T).GetProperties().Where(p => p.CanRead);
        var primaryKey = properties.FirstOrDefault(p => p.CustomAttributes.Any(attr => attr.AttributeType == typeof(KeyAttribute)));

        var parameters = properties.Select(p => new QueryParameter($"@{p.Name}", null)).ToArray();
        var insertSql = $"insert into {table} ({string.Join(", ", properties.Select(p => p.Name))}) values ({string.Join(", ", properties.Select(p => $"@{p.Name}"))})";
        bool checkExec = false;
        foreach (var entity in entities)
        {
             var entityParameters = properties.Select(p => new QueryParameter($"@{p.Name}", p.GetValue(entity))).ToArray();
             // Check if the entity already exists in the database by its primary key
             var primKey = entityParameters[0].Name.Substring(1);
             var existsSql = $"select count(*) from {table} where {primKey} = {entityParameters[0].Name}";
             var exists = await template.ExecuteCountAsync(existsSql, new QueryParameter(entityParameters[0].Name, entityParameters[0].Value));

             if (exists>0)
             {                
                 checkExec = await UpdateAsync(entity, table); 
             }
             else
             {
                 checkExec = await template.ExecuteAsync(insertSql, entityParameters) == 1;
             }

        }
        return checkExec;
    }


}
