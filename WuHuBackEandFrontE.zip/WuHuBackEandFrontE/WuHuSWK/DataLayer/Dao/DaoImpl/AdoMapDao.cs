﻿using DataLayer.Domain;
using System.Data;

namespace DataLayer.Dao.DaoImpl;

public class AdoMapDao
{
    public static User MapRowToUser(IDataRecord row) =>
    new(
        id: (int)row["Id"],
        email: (string)row["Email"],
        username: (string)row["Username"],
        password: (string)row["Password"],
        role: (UserRole)row["Role"]
    );


    public static Team MapRowToTeam(IDataRecord row) =>
    new(
        id: (string)row["Id"],
        name: (string)row["Name"]  ,         
        player_id: (int)row["PlayerId"]
    );

    public static Player MapRowToPlayer(IDataRecord row) =>
    new(
       id: (int)row["Id"],
       full_name: (string)row["FullName"],
       nick_name: (string)row["NickName"],
       photo_url: (string)row["PhotoUrl"],
       strength: (double)row["Strength"]      
    );


    public static Match MapRowToMatch(IDataRecord row) =>
    new(
        id: (string)row["Id"],
        team1_name: (string)row["Team1Name"],
        team2_name: (string)row["Team2Name"],
        start_time: (DateTime)row["StartTime"],
        end_time: (DateTime)row["EndTime"],
        team1_score: (int)row["Team1Score"],
        team2_score: (int)row["Team2Score"],
        name: (string)row["Name"],
        stadion: (string)row["Stadion"],
        city: (string)row["City"],
        status: (GameStatus)row["Status"]
    );

    public static PlayingTime MapRowToPlayingTime(IDataRecord row) =>
    new(
        id: (int)row["Id"],
        match_id: (int)row["MatchId"],
        player_id: (int)row["PlayerId"],
        minute_duration: (TimeSpan)row["MinuteDuration"]
    );
   

    public static AttendanceTime MapRowToAttendanceTime(IDataRecord row) =>
    new(
        id: (string)row["Id"],
        days_of_week: (DayOfWeek)row["DayInTheWeek"],
        start_time: (TimeOnly)row["StartTime"],
        end_time: (TimeOnly)row["EndTime"],
        player_id: (int)row["PlayerId"]
    );
   
}
