﻿namespace DataLayer.Dao;
public interface IGenericDao<T> : IDao
{
    Task<IEnumerable<T>> FindAllAsync(string table);
    Task<T?> FindByIdAsync(object id, string table);
    Task<bool> DeleteByIdAsync(object id, string table);

    Task<T?> FindLastAsync(string table) { return default!; }
    Task<int> CountAllElements(string table);

    Task<IEnumerable<T?>> FindTByProperties(IDictionary<string, object> properties, string sql)
    {
        return (Task<IEnumerable<T?>>)Enumerable.Empty<T>();
    }

    Task<int> CountTWhereProperties(IDictionary<string, object> properties, string table);

    Task<IEnumerable<T>> FindTByAnyCriteria(IDictionary<string, object> criteria, string tableName);
    Task<bool> UpdateAsync(T obj, string table);
    Task<bool> StoreAsync(T obj, string table);
    Task<bool> StoreAllAsync(IEnumerable<T> entities, string table);

}
