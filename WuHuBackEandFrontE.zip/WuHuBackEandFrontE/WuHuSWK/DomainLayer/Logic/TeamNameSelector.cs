﻿namespace DomainLayer.Logic;

public class TeamNameSelector
{
  
     private Queue<string> teamNames;

     public TeamNameSelector(IList<string> names)
     {
         teamNames = new Queue<string>(names);
     }

     public string Select()
     {
         if (teamNames.Count == 0)
         {
             throw new Exception("No team names remaining");
         }
         return teamNames.Dequeue();
     }
    

}

