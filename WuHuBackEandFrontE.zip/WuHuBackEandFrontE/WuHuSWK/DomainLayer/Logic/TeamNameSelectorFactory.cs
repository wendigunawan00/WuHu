﻿namespace DomainLayer.Logic;

public class TeamNameSelectorFactory : ITeamNameSelectorFactory
{
    public TeamNameSelector Create(IList<string> names)
    {
        return new TeamNameSelector(names);
    }
}

