﻿namespace DomainLayer.Logic;
public interface ITeamNameSelectorFactory
{
    TeamNameSelector Create(IList<string> names);
}
