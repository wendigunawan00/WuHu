﻿using DataLayer.Dao;
using DataLayer.DataGenerator;
using DataLayer.Domain;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;

namespace DomainLayer.Logic;

public class GamePlan
{
    private List<Match> _matches;
    private readonly IGenericDao<Team> _teamDao;
    private ITeamNameSelectorFactory _tnSelectorFactory;
    private readonly IGenericDao<Player> _playerDao;
    private readonly IGenericDao<AttendanceTime> _attendanceTimeDao;
    private readonly string _table = "Teams$";
    private TeamNameSelector _tnSelector;
    private readonly List<string> teamNames = DataGenerator.TEAM_NAMES;


    //public GamePlan(IGenericDao<Team> teamDao, IGenericDao<Player> playerDao)
    //{
    //    _matches = new List<Match>();
    //    _teamDao = teamDao;
    //    _tnSelector = new TeamNameSelector(teamNames);
    //    _playerDao = playerDao;
    //}
    public GamePlan(IGenericDao<Team> teamDao, IGenericDao<Player> playerDao, IGenericDao<AttendanceTime> attendanceTimeDao, ITeamNameSelectorFactory tnSelectorFactory)
    {
        _matches = new List<Match>();
        _teamDao = teamDao;
        _tnSelectorFactory = tnSelectorFactory;
        _playerDao = playerDao;
        _attendanceTimeDao = attendanceTimeDao;
    }

    // public async Task DrawMatches(List<Player> players, int numMatchesToDraw)
    public async Task<List<Match>> DrawMatches()
    {
        Random random;
        _tnSelector = _tnSelectorFactory.Create(teamNames);
        var iEnumerablePlayers = await _playerDao.FindAllAsync("Players$");
        var players = iEnumerablePlayers.ToList(); 

        // Calculate the number of matches based on the number of players
        int numPlayers = players.Count();
        int playersPerTeam = 11;
        int numMatchesToDraw = numPlayers / (2 * playersPerTeam);
        // If the number of players is odd, add a player from the list into the list for second time randomly
        if (numPlayers % 2 != 0)
        {
            random = new Random(); 
            players.Add(players[random.Next(numPlayers)]);
        }
        // create Attendance Time and save to data base
        /*foreach( var p in players)
        {
            IEnumerable<AttendanceTime> attendanceTimes = p.GenerateAttendanceTimesByDays(4);
            await _attendanceTimeDao.StoreAllAsync(attendanceTimes,"AttendanceTimes$");
        }*/
        // SelectMany to flatten the container form list of list become list
        var attendanceTimes = players.SelectMany(p => p.GenerateAttendanceTimesByDays(4));
        await _attendanceTimeDao.StoreAllAsync(attendanceTimes, "AttendanceTimes$");


        //await Task.WhenAll(players.Select(async p => {
        //    var attendanceTimes = p.GenerateAttendanceTimesByDays(4);
        //    await _attendanceTimeDao.StoreAllAsync(attendanceTimes, "AttendanceTimes$");
        //}));

        IList<Player> teamA = new List<Player>();
        IList<Player> teamB = new List<Player>();
        Task<Team> team1, team2;
        Player? opponent;
        for (int i = 0; i < numMatchesToDraw; i++)
        {
            random = new Random();
            HashSet<Player> opponentSet = new HashSet<Player>();
            var timeMatchCreated = DataGenerator.START_TIMES[random.Next(DataGenerator.START_TIMES.Count)];
            var timeDiff = DateTime.Now - timeMatchCreated;
            DateTime? endTime;
            // Select Team Name
            var team1Name = _tnSelector.Select();
            var team2Name = _tnSelector.Select();

            // Get available Players
            var availablePlayers = await GetAvailablePlayersAsync(players, timeMatchCreated);
            // Divide the list of players into pairs
            var pairs = DivideIntoPairs(availablePlayers);            

            // Shuffle the list of availablePlayers randomly
            availablePlayers = Shuffle(availablePlayers);

            
            foreach (var pair in pairs)
            {
                opponent = SelectOpponent(pair[0], availablePlayers);
                team1 = createTeamAsync(team1Name, pair[0].Id);
                team2 = createTeamAsync(team2Name, opponent.Id);
                await Task.WhenAll(team1, team2);
                teamA.Add(pair[0]);
                teamB.Add(opponent);
            }


            var match = new Match
            {
                Id = $"M-{team1Name[0].ToString().ToUpper()}-{team2Name.Substring(0, 1).ToUpper()}-{timeMatchCreated}",
                Team1Name = team1Name,
                Team2Name = team2Name,
                StartTime = timeMatchCreated,
                Stadion = "StadionX",
                City = "Linz",
                Name = ""

            };
            if (timeDiff.TotalHours > 1.5)
            {
                match.EndTime = timeMatchCreated.AddHours(1.5);
                match.Team1Score = random.Next(9);
                match.Team2Score = random.Next(9);
                match.Status = GameStatus.ENDED;
                match.UpdateTeamStrengths(teamA,teamB, match.Team1Score, match.Team2Score);
            }
            else
            {
                match.EndTime = timeMatchCreated.AddMinutes(30);
                match.Team1Score = random.Next(3);
                match.Team2Score = random.Next(3);
                match.Status = GameStatus.RUNNING;

            }
            // Add the match to the game plan
            _matches.Add(match);
            
        }
        var x = _matches;

        return _matches;
    }

    /*private async Task<bool[]> CanPlayInMatchBatchAsync(IEnumerable<Player> players, DateTime dateTime)
    {
        var tasks = players.Select(p => Task.Run(() => p.CanPlayInMatch(dateTime)));
        return await Task.WhenAll(tasks);
    }*/

    public async Task<bool[]> CanPlayInMatchBatchAsync(IEnumerable<Player> players, DateTime dateTime)
    {
        var tasks = players.Select(p => p.CanPlayInMatchAsync(dateTime));
        return await Task.WhenAll(tasks);
    }

    private async Task<bool[]> CanPlayInMatchBatchAsync2(IEnumerable<Player> players, DateTime dateTime)
    {
        var tasks = players.Select(p => Task.Run(() => p.CanPlayInMatch(dateTime)));
        return await Task.WhenAll(tasks);
    }

    private async Task<Team> createTeamAsync(string teamName, int playerId)
    {
        Dictionary<string, object> iDict = new Dictionary<string, object>();
        iDict.Add("Name", teamName);

        IEnumerable<Team> foundTeamByName = await _teamDao.FindTByAnyCriteria(iDict, _table);
        var count = await _teamDao.CountAllElements(_table);
        // team is not listed
        Team team = new Team($"T{count + 1}-P{playerId}",teamName,playerId);
        if (!foundTeamByName.IsNullOrEmpty()) // team is there here Updating
        {
            team = new Team($"T{foundTeamByName.ToArray()[0].Id.Split('-')[0]}-P{playerId}",teamName, playerId);
        }
        await _teamDao.StoreAsync(team,"Teams$");
        return team;

    }
    private List<Player[]> DivideIntoPairs(List<Player> players)
    {
        var pairs = new List<Player[]>();
        int onlyEven = 0;
        if(players.Count%2 != 0)
        {
            onlyEven = players.Count -1;
        }

        for (int i = 0; i < onlyEven; i += 2)
        {
            pairs.Add(new[] { players[i], players[i + 1] });
        }
        
        return pairs;
    }

    private List<Player> Shuffle(List<Player> players)
    {
        var random = new Random();
        return players.OrderBy(p => random.Next()).ToList();
    }

    private Player SelectOpponent(Player player, List<Player> players)
    {
        var random = new Random();

        // Filter out the player themselves and any dummy players
        var eligibleOpponents = players.Where(p => p.Id != player.Id && p.Id != -1).ToList();

        // Sort the eligible opponents by their strength in ascending order
        eligibleOpponents = eligibleOpponents.OrderBy(p => p.Strength).ToList();

        // Calculate the index of the player in the sorted list
        var playerIndex = eligibleOpponents.IndexOf(player);

        // Choose an opponent with similar playing strength to the player
        // by selecting an index within a certain range around the player's index
        var range = 2; // You can adjust this range based on your desired level of randomness
        var opponentIndex = random.Next(Math.Max(playerIndex - range, 0), Math.Min(playerIndex + range + 1, eligibleOpponents.Count));

        return eligibleOpponents[opponentIndex];
    }

    private async Task<Player> SelectOpponentAsync(Player player, List<Player> players, DateTime timeMatchCreated)
    {
        var random = new Random();

        // Filter out the player themselves and any dummy players
        var eligibleOpponents = players.Where(p => p.Id != player.Id && p.Id != -1).ToList();

        // Sort the eligible opponents by their strength in ascending order
        eligibleOpponents = eligibleOpponents.OrderBy(p => p.Strength).ToList();

        // Calculate the index of the player in the sorted list
        var playerIndex = eligibleOpponents.IndexOf(player);

        // Choose an opponent with similar playing strength to the player
        // by selecting an index within a certain range around the player's index
        var range = 2; // You can adjust this range based on your desired level of randomness
        var opponentIndex = random.Next(Math.Max(playerIndex - range, 0), Math.Min(playerIndex + range + 1, eligibleOpponents.Count));

        var opponent = eligibleOpponents[opponentIndex];
        var canPlay = await opponent.CanPlayInMatchAsync(timeMatchCreated);
        if (!canPlay)
        {
            return null;
        }

        return opponent;
    }

    private async Task<List<Player>> GetAvailablePlayersAsync2(IEnumerable<Player> players, DateTime dateTime)
    {
        var tasks = players.Select(async p =>
        {
            var canPlay = await p.CanPlayInMatchAsync(dateTime);
            return new { Player = p, CanPlay = canPlay };
        });

        var results = await Task.WhenAll(tasks);

        return results.Where(r => r.CanPlay).Select(r => r.Player).ToList();
    }


    private async Task<List<Player>> GetAvailablePlayersAsync(IEnumerable<Player> players, DateTime dateTime)
    {
        var tasks = players.Select(async p => {
            var canPlay = await Task.Run(() => p.CanPlayInMatch(dateTime));
            return new { Player = p, CanPlay = canPlay };
        });

        var results = await Task.WhenAll(tasks);

        return results.Where(r => r.CanPlay).Select(r => r.Player).ToList();
    }

}

