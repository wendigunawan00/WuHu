﻿using DataLayer.Dao;
using DataLayer.Domain;
using Microsoft.Extensions.Hosting;

namespace DomainLayer.Logic;
public class PlayerStrengthUpdateService : BackgroundService
{
    private readonly PlayerStrengthGenerator _playerStrengthGenerator;
    private readonly IGenericDao<Match> _matchDao;

    public PlayerStrengthUpdateService(PlayerStrengthGenerator playerStrengthGenerator, IGenericDao<Match> matchDao)
    {
        _playerStrengthGenerator = playerStrengthGenerator;
        _matchDao = matchDao;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            // Wait for 60 minutes before checking for ended matches again
            await Task.Delay(TimeSpan.FromMinutes(60), stoppingToken);
            // Get all matches that have ended yet
            var properties = new Dictionary<string, object>();
            properties["EndTime"] = DateTime.Now;
            var sql = "SELECT * FROM Matches WHERE EndTime < @EndTime";
            var matches = await _matchDao.FindTByProperties(properties, sql);

            // Check if any match has ended
            foreach (var match in matches)
            {               
                await _playerStrengthGenerator.UpdatePlayerStrength(match);             
            }
        }
    }
}
