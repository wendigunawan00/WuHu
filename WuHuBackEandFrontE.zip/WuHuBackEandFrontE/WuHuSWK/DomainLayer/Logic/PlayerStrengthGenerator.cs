﻿using DataLayer.Dao;
using DataLayer.Domain;
using System.Collections.Generic;

namespace DomainLayer.Logic;


public class PlayerStrengthGenerator
{
    // Elo rating system constants
    private const int K = 32; // maximum amount of rating points that can be gained or lost in a single game
    private const double DecayFactor = 0.5;
    private IGenericDao<Player> _playerDao;
    private string _table;

    public PlayerStrengthGenerator(IGenericDao<Player> playerDao,string table)
    {
        _playerDao = playerDao;
        _table = table;
    }
        

    public async Task UpdatePlayerStrength(Match match)
    {
        // Find which team wins
        int team1Won = match.Team1Score > match.Team2Score ? 1 : 0;

        // Find List of player from both team   
        List<Player?> playerTeam1 = (await FindPlayersByMatchIdAndTeamName(match,match.Team1Name)).ToList();
        List<Player?> playerTeam2 = (await FindPlayersByMatchIdAndTeamName(match,match.Team2Name)).ToList();               

        // Get the team's strength
        double team1Strength = playerTeam1.Sum(p => p?.Strength ?? 0);
        double team2Strength = playerTeam2.Sum(p => p?.Strength ?? 0);
        // Calculate the expected win probability based on the player's and opponent's strength ratings
        double expectedWinProbability = 1 / (1 + Math.Pow(10, (team2Strength - team1Strength) / (11* 400)));

        // Calculate the actual win probability based on whether the team won or lost the game
        double actualWinProbability = match.Team1Score >= match.Team2Score ? 1 : 0;  

        // Update the team's strength based on their win-lost against stronger/weaker team
        List<Player> playerTeam1AndTeam2 = match.UpdateTeamStrengths(playerTeam1, playerTeam2);
        int halfCount = playerTeam1AndTeam2.Count / 2;
        playerTeam1 = playerTeam1AndTeam2.Take(halfCount).ToList();
        playerTeam2 = playerTeam1AndTeam2.Skip(halfCount).ToList();

        // Update the player's strength rating based on the result of the game
        double ratingChange = K * (actualWinProbability - expectedWinProbability);

        playerTeam1.ForEach(p => p.Strength += ratingChange);
        playerTeam2.ForEach(p => p.Strength += ratingChange);

        // Decay the player's rating over time if no games are played
        int daysSinceLastGame = (DateTime.Now - match.StartTime).Days;
        if (daysSinceLastGame > 30)
        {
            double decayFactor = Math.Pow(DecayFactor, daysSinceLastGame);
            playerTeam1.ForEach(p => p.Strength += ratingChange);
            playerTeam2.ForEach(p => p.Strength += ratingChange);
        }

        // Save the updated player to the database or wherever the player data is stored
        playerTeam1.ForEach(async p => await _playerDao.StoreAsync(p,_table));
        playerTeam2.ForEach(async p => await _playerDao.StoreAsync(p,_table));
    }

    
    public async Task<IEnumerable<Player?>> FindPlayersByMatchIdAndTeamName(Match match,string teamName)
    {
        string sql = "SELECT p.* FROM Player p JOIN Team t ON p.Id = t.PlayerId JOIN Match m ON t.Name = m.Team1Name OR t.Name = m.Team2Name" +
            "WHERE t.Name = @teamName AND m.Id = @matchId";
        var properties = new Dictionary<string, object>()
        {
            { "TeamName", teamName }, 
            { "MatchId", match.Id }            
        };
        return await _playerDao.FindTByProperties(properties, sql);
    }

   

}

