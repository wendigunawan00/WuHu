﻿using DataLayer.Dao;
using DataLayer.Domain;
using Microsoft.Extensions.Hosting;

namespace DomainLayer.Logic;
public class PlayerStrengthUpdateService2 : BackgroundService
{
    private readonly PlayerStrengthGenerator _playerStrengthGenerator;
    private readonly IGenericDao<Match> _matchDao;
    private readonly Timer _timer;

    public PlayerStrengthUpdateService2(PlayerStrengthGenerator playerStrengthGenerator, IGenericDao<Match> matchDao)
    {
        _playerStrengthGenerator = playerStrengthGenerator;
        _matchDao = matchDao;
        _timer = new Timer(OnTimerCallback, null, TimeSpan.Zero, TimeSpan.FromMinutes(60));
    }

    private async void OnTimerCallback(object state)
    {
        // Get all matches that have ended yet
        var properties = new Dictionary<string, object>();
        properties["EndTime"] = DateTime.Now;
        var sql = "SELECT * FROM Matches WHERE EndTime < @EndTime";
        var matches = await _matchDao.FindTByProperties(properties, sql);

        // Check if any match has ended
        foreach (var match in matches)
        {
            await _playerStrengthGenerator.UpdatePlayerStrength(match);
        }
    }

    public override void Dispose()
    {
        _timer.Dispose();
        base.Dispose();
    }

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // This method is required by the BackgroundService base class, but we don't need to use it in this case.
        return Task.CompletedTask;
    }
}
