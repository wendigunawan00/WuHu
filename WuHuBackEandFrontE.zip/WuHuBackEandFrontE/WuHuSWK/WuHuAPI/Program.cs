////var builder = WebApplication.CreateBuilder(args);

////// Add services to the container.

////builder.Services.AddControllers();
////// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
////builder.Services.AddEndpointsApiExplorer();
////builder.Services.AddSwaggerGen();

////var app = builder.Build();

////// Configure the HTTP request pipeline.
////if (app.Environment.IsDevelopment())
////{
////    app.UseSwagger();
////    app.UseSwaggerUI();
////}

////app.UseHttpsRedirection();

////app.UseAuthorization();

////app.MapControllers();

////app.Run();


//using ApplicationLayer.Impl;
//using ApplicationLayer;


//using InfrastructureLayer.Common;
//using Microsoft.AspNetCore.Authentication.JwtBearer;
//using Microsoft.AspNetCore.Builder;
//using Microsoft.IdentityModel.Tokens;
//using System;
//using System.Text;
//using DataLayer.Domain;
//using DataLayer.Dao.DaoImpl;
//using DomainLayer.Logic;

//var builder = WebApplication.CreateBuilder(args);

//// Configure Services
//builder.Services.AddRouting(options => options.LowercaseUrls = true);
//builder.Services
//    .AddControllers()
//    .AddNewtonsoftJson()
//    .AddXmlDataContractSerializerFormatters();

//builder.Services.AddAuthentication(option =>
//{
//    option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
//    option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
//    option.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
//}).AddJwtBearer(option =>
//{
//    option.SaveToken = true;
//    option.RequireHttpsMetadata = false;
//    option.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
//    {
//        ValidateIssuer = true,
//        ValidateAudience = true,
//        ValidAudience = ConfigurationUtil.GetConfiguration()["JWT:ValidAudience"],
//        ValidIssuer = ConfigurationUtil.GetConfiguration()["JWT:ValidIssuer"],
//        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(ConfigurationUtil.GetConfiguration()["JWT:Key"]))
//    };
//});

//builder.Services.AddMvc();
//builder.Services.AddScoped<IManagementLogic<Match>>(_ =>
//    new ManagementLogic<Match>(new AdoGenericDao<Match>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Matches$")
//);
//builder.Services.AddScoped<IManagementLogic<Team>>(_ =>
//    new ManagementLogic<Team>(new AdoGenericDao<Team>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Teams$")
//);
//builder.Services.AddScoped<IManagementLogic<User>>(_ =>
//    new ManagementLogic<User>(new AdoGenericDao<User>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Users$")
//);
//builder.Services.AddScoped<IManagementLogic<Player>>(_ =>
//    new ManagementLogic<Player>(new AdoGenericDao<Player>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Players$")
//);
//builder.Services.AddScoped<IManagementLogic<AttendanceTime>>(_ =>
//    new ManagementLogic<AttendanceTime>(new AdoGenericDao<AttendanceTime>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "AttendanceTimes$")
//);
//builder.Services.AddScoped<IManagementLogic<PlayingTime>>(_ =>
//    new ManagementLogic<PlayingTime>(new AdoGenericDao<PlayingTime>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "PlayingTimes$")
//);

//builder.Services.AddSingleton<GamePlan>(_ => new GamePlan(new AdoGenericDao<Team>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")),
//    new AdoGenericDao<Player>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")) ));


//builder.Services.AddAutoMapper(typeof(Program));
//builder.Services.AddCors(
//    builder => builder.AddDefaultPolicy(
//        policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));
//builder.Services.AddOpenApiDocument(
//    settings => settings.PostProcess = doc => doc.Info.Title = "WuHu");


//var app = builder.Build();


//// Configure Middleware
//app.UseHttpsRedirection();
//app.UseStaticFiles();
//app.UseRouting();
//app.UseOpenApi();
//app.UseSwaggerUi3(settings => settings.Path = "/swagger");
//app.UseReDoc(settings => settings.Path = "/redoc");
//app.UseCors();
//app.UseAuthentication();
//app.UseAuthorization();


//// Configure Endpoints
//app.MapControllers();


//app.Run();



using WuHuAPI;

var builder = WebApplication.CreateBuilder(args);


// Use Startup.cs
var startup = new Startup(builder.Configuration);
startup.ConfigureServices(builder.Services);

var app = builder.Build();
//startup.Configure(app,app.Environment);
startup.Configure(app);

app.Run();

