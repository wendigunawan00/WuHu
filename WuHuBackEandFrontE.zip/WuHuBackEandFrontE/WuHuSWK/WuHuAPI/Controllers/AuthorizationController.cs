﻿using ApplicationLayer;
using AutoMapper;
using DataLayer.Domain;
using DataLayer.Dto;
using Microsoft.AspNetCore.Mvc;
using SecurityLayer;
using WuHuAPI.Info;

namespace WuHuAPI.Controllers;


// ----------------------- Authorization && Authentication -------------------------------
// -----------------Bearer Token = Token based Authorization using JWT Token -------------

[Route("api/[controller]s")]
[ApiController]
[ApiConventionType(typeof(WebApiConventions))]
public class AuthorizationController : ControllerBase
{
    private IAuthenticate _auth;
    private readonly IManagementLogic<User> _logic;
    private readonly IMapper _mapper;
    public AuthorizationController(IAuthenticate auth, IMapper mapper, IManagementLogic<User> logic)
    {
        _auth = auth;
        _mapper = mapper;
        _logic = logic;
        _auth.setMapper(mapper ?? throw new ArgumentNullException(nameof(mapper)));
    }


    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] UserDto admin)
    {
        var result = await _auth.AuthenticateUser(admin);
        if (result is null)
        {
            return NotFound("Wrong Email or Password");
        }
        return Ok(result);
    }

    /// <summary>
    /// Returns a list of users
    /// </summary>
    /// <returns>a list of users</returns>
    [HttpGet]
    public async Task<IEnumerable<UserDto>> GetUsers()
    {
        var teams = await _logic.GetAll();
        return _mapper.Map<IEnumerable<UserDto>>(teams);
    }

}

