using ApplicationLayer;
using AutoMapper;
using DataLayer.Domain;
using DataLayer.Dto;
using DomainLayer.Logic;
using Microsoft.AspNetCore.Mvc;
using WuHuAPI.Info;

namespace WuHuAPI.Controllers;

// ---------------------- Create Update Get Match For Admin and Player -------------------
// ---------------------- Update NOT allowed for normal User -----------------------------
[Route("api/[controller]es")]
[ApiController]
public class MatchController : ControllerBase
{

    private readonly IManagementLogic<Match> _logic;
    private readonly IManagementLogic<Team> _logicTeam;
    private readonly GamePlan _gamePlan;
    private IMapper _mapper;


    public MatchController(IManagementLogic<Match> matchLogicInstance,IManagementLogic<Team> teamLogicInstance, GamePlan gamePlan, IMapper mapper)
    {
        _logic = matchLogicInstance;
        _logicTeam = teamLogicInstance;
        _gamePlan = gamePlan;
        _mapper = mapper;
    }

    /// <summary>
    /// Returns a Match by UserID.
    /// </summary>
    /// <param name="teamId">ID</param>      
    /// <returns>The Team with the given ID</returns>
    [HttpGet("{matchId}")]
    public async Task<ActionResult<MatchDto>> GetMatchById(string matchId)
    {
        Match? foundMatch = await _logic.Search(matchId);
        if (foundMatch is null)
        {
            return NotFound(StatusInfo.InvalidMatchId(matchId));
        }
        //return Ok(Match.ToDto());
        return _mapper.Map<MatchDto>(foundMatch);
    }

    /// <summary>
    /// Empty an open match of customer with given the customer id
    /// </summary>
    [HttpDelete("{matchId}/{teamA}/{teamB}")]
    //[Authorize]
    public async Task<ActionResult> DeleteMatchById([FromRoute] string matchId, string teamA, string teamB)
    {

        var foundMatch = await _logic.Search(matchId);

        if (foundMatch is not null)
        {
            await _logic.Delete(foundMatch.Id);

            return Ok("Finished Deleting");
        }
        else
        {
            return NotFound();
        }
    }

    /// <summary>
    /// Returns all open matches all customers.
    /// </summary>
    /// <returns> all matches  with open status</returns>
    [HttpGet]
    //[Authorize]
    public async Task<IEnumerable<MatchDto>> ShowMatches()
    {
        return _mapper.Map<IEnumerable<MatchDto>>(await _logic.GetAll());
    }

    /// <summary>
    /// Create or update match     /// </summary>
    /// <returns>if success, show an open match of a customer</returns>
    [Route("[action]")]
    [HttpPost]
    public async Task<ActionResult<MatchDto>> CreateOrUpdateMatch(string teamA, string teamB)
    {
        var teamAValid=  _logic.IsValidTeam(teamA);
        var teamBValid = _logic.IsValidTeam(teamB);
        var bothTeam = await Task.WhenAll(teamAValid, teamBValid);
        if (!bothTeam[0] || !bothTeam[1]) { 
            return NotFound($"{StatusInfo.InvalidTeamNumber(teamA)} {StatusInfo.InvalidTeamNumber(teamB)}");
        }
        var countMatch = await _logic.CountAll(); 

        Match match = new Match($"M-{teamA[0].ToString().ToUpper()}-{teamB.Substring(0, 1).ToUpper()}-{countMatch}",
            teamA,teamB,DateTime.Now, DateTime.Now.AddHours(1.5),0, 0);
        match.Stadion = "StadionZero";
        match.Name = "Elimination";
        match.City = "Linz";
        match.Status = GameStatus.NOTSTARTED;
        await _logic.Add(match);
        return CreatedAtAction(actionName: nameof(GetMatchById),
            routeValues: new { MatchId = match.Id },
            //value: Match.ToDto()
            value: _mapper.Map<TeamDto>(match)
            );
    }

    [HttpPost("draw-matches")]
    public async Task<ActionResult<List<Match>>> DrawMatches()
    {
        var matches = await _gamePlan.DrawMatches();       
        await _logic.AddAll(matches);      
        return Ok(matches);
    }

    /// <summary>
    /// Update a Match with the Match id given and show it back if success updating
    /// </summary>
    [HttpPut("{matchId}")]
    //[Authorize]
    public async Task<ActionResult<MatchDto>> UpdateMatch(string matchId, [FromBody] MatchDto matchDto)
    {
        Match? foundMatch = (Match?)await _logic.Search(matchId);
        if (foundMatch is null)
        {
            return NotFound(StatusInfo.InvalidMatchId(matchId));
        }

        foundMatch = new Match(matchId, matchDto.Team1Name, matchDto.Team2Name, matchDto.StartTime,matchDto.EndTime, matchDto.Team1Score,matchDto.Team2Score);
        foundMatch.Stadion = matchDto.Stadion;
        foundMatch.City = foundMatch.City;
        foundMatch.Name = foundMatch.Name;
        foundMatch.Status = foundMatch.Status;

        await _logic.Update(foundMatch);

        return Ok("Finished Updating");
    }

}


