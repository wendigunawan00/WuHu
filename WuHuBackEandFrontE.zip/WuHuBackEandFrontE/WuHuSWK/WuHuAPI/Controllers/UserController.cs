using ApplicationLayer;
using AutoMapper;
using DataLayer.Domain;
using DataLayer.Dto;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using WuHuAPI.Info;

namespace WuHuAPI.Controllers
{   
    //------------------- Create Update Get User --------------------
    [ApiController]
    [Route("api/[controller]s")]
    public class UserController : ControllerBase    {


        private readonly IManagementLogic<User> _logic; 
        private readonly IManagementLogic<Player> _logicPlayer; 
        private readonly IMapper _mapper;


        public UserController(IManagementLogic<User> logic,IManagementLogic<Player> logicPlayer, IMapper mapper)
        {
            _logic = logic ?? throw new ArgumentNullException(nameof(logic));
            _logicPlayer = logicPlayer ?? throw new ArgumentNullException(nameof(logic));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(_mapper));
        }

        private async Task<UserDto?> GetLast()
        {
            var Users = await _logic.GetAll();
            return _mapper.Map<UserDto>(Users.LastOrDefault());
        }


        /// <summary>
        /// Returns a User by UserID.
        /// </summary>
        /// <param name="UserId">ID</param>      
        /// <returns>The User with the given ID</returns>
        [HttpGet("{UserId}")]
        public async Task<ActionResult<UserDto>> GetUserById(int UserId)
        {
            User? prod = await _logic.Search(UserId);
            if (prod is null)
            {
                return NotFound(StatusInfo.InvalidPersonId(UserId));
            }
            //return Ok(User.ToDto());
            return _mapper.Map<UserDto>(prod);
        }

        /// <summary>
        /// Returns a list of Users
        /// </summary>
        /// <returns>a list of Users</returns>
        [HttpGet]
        public async Task<IEnumerable<UserDto>> GetUsers()
        {
            var Users = await _logic.GetAll();
            return _mapper.Map<IEnumerable<UserDto>>(Users);
        }

        /// <summary>
        /// Returns a created User with the id after creating a User
        /// </summary>
        [HttpPost]
        //[Authorize]
        public async Task<ActionResult<UserDto>> CreateUser([FromBody] UserDto userDto)
        {
            IDictionary<string, object> iDict = new Dictionary<string, object>();
            iDict.Add("email",userDto.Email);
            IEnumerable<User?> foundUser = await _logic.GetTByX(iDict);

            if (!foundUser.IsNullOrEmpty())
            {
                return NoContent();
            }

            var count = await _logic.CountAll();
            User user = new User(count+1 , userDto.Email,userDto.Username,userDto.Password,userDto.Role);
           
            await _logic.Add(user);
            return CreatedAtAction(actionName: nameof(GetUserById),
                routeValues: new { UserId = user.Id },
                //value: User.ToDto()
                value: _mapper.Map<UserDto>(User)
                );
        }

        /// <summary>
        /// Update a User with the User id given and show it back if success updating
        /// </summary>
        [HttpPut("{UserId}")]
        //[Authorize]
        public async Task<ActionResult<UserDto>> UpdateUser(int UserId, [FromBody] UserDto userDto)
        {
            User? foundUser = (User?) await _logic.Search(UserId);
            if (foundUser is null)
            {
                return NotFound(StatusInfo.InvalidPersonId(UserId));
            }
            foundUser = new User(UserId,userDto.Email, userDto.Username,userDto.Password, userDto.Role);
            

            await _logic.Update(foundUser);

            return Ok("Finished Updating");
        }


        /// <summary>
        /// Delete a User with the User-id given
        /// </summary>
        [HttpDelete("{UserId}")]
        //[Authorize]
        public async Task<ActionResult> DeleteUser([FromRoute] int UserId)
        {
            if (await _logic.Delete(UserId))
            {
                return Ok("Finished Deleting");
            }
            else
            {
                return NotFound();
            }
        }
    }
}