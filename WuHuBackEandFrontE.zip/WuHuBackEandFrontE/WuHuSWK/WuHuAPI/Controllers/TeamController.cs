using ApplicationLayer;
using AutoMapper;
using DataLayer.Domain;
using DataLayer.Dto;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using WuHuAPI.Info;

namespace WuHuAPI.Controllers;

// --------------------- Create Update Get Team For Admin and Team ------------------------
// --------------------- Create and Update NOT allowed for normal User ----------------------
[ApiController]
[Route("api/[controller]s")]
public class TeamController : ControllerBase
{
    private readonly IManagementLogic<Team> _logic;
    private readonly IManagementLogic<Player> _logicPlayer;
    private IMapper _mapper;


    public TeamController(IManagementLogic<Team> teamLogicInstance,IManagementLogic<Player> playerLogicInstance, IMapper mapper)
    {
        _logic = teamLogicInstance;
        _logicPlayer = playerLogicInstance;
        _mapper = mapper;
    }

    /// <summary>
    /// Returns a list of Teamss
    /// </summary>
    /// <returns>a list of Teams</returns>
    [HttpGet]
    public async Task<IEnumerable<TeamDto>> GetTeams()
    {
        var teams = await _logic.GetAll();
        return _mapper.Map<IEnumerable<TeamDto>>(teams);
    }
    /// <summary>
    /// Returns a User by UserID.
    /// </summary>
    /// <param name="teamId">ID</param>      
    /// <returns>The Team with the given ID</returns>
    [HttpGet("{TeamId}")]
    public async Task<ActionResult<TeamDto>> GetTeamById(string teamId)
    {
        Team? foundTeam = await _logic.Search(teamId);
        if (foundTeam is null)
        {
            return NotFound(StatusInfo.InvalidTeamId(teamId));
        }
        //return Ok(Team.ToDto());
        return _mapper.Map<TeamDto>(foundTeam);
    }

    /// <summary>
    /// Returns a created Team with the id and its member or update the team if
    /// a team already existed
    /// </summary>
    [HttpPost]
    //[Authorize]
    public async Task<ActionResult<TeamDto>> CreateOrUpdateTeamWithMember([FromBody] TeamDto teamDto)
    {        
        var foundPlayer = await _logicPlayer.Search(teamDto.PlayerId);
        // if no id of player existed then can not add a team
        if (foundPlayer is null)
        {
            return NotFound(StatusInfo.InvalidPersonId(teamDto.PlayerId));
        }
        var iDict = new Dictionary<string, object>();
        iDict.Add("name", teamDto.Name);
        var foundTeamByName = await _logic.GetTByX(iDict);
        var count = await _logic.CountAll();
        // team is not listed
        Team team = new Team($"T{count + 1}-P{foundPlayer.Id}", teamDto.Name, teamDto.PlayerId);

        if (!foundTeamByName.IsNullOrEmpty()) // team is there here Updating
        {
            team = new Team($"T{foundTeamByName.ToArray()[0].Id.Split('-')[0]}-P{foundPlayer.Id}", teamDto.Name, teamDto.PlayerId);

        }
       
        await _logic.Add(team);
        return CreatedAtAction(actionName: nameof(GetTeamById),
            routeValues: new { TeamId = team.Id },
            //value: Team.ToDto()
            value: _mapper.Map<TeamDto>(team)
            );
    }


    /// <summary>
    /// Delete a Team with the Team-id given
    /// </summary>
    [HttpDelete("{TeamId}")]
    //[Authorize]
    public async Task<ActionResult> DeleteTeam([FromRoute] string TeamId)
    {
        if (await _logic.Delete(TeamId))
        {
            return Ok("Finished Deleting");
        }
        else
        {
            return NotFound();
        }
    }


    /// <summary>
    /// Update a Team with the Team id given and show it back if success updating
    /// </summary>
    [HttpPut("{teamId}")]
    //[Authorize]
    public async Task<ActionResult<TeamDto>> UpdateTeam(string teamId, [FromBody] TeamDto teamDto)
    {
        Team? foundTeam = (Team?)await _logic.Search(teamId);
        if (foundTeam is null)
        {
            return NotFound(StatusInfo.InvalidTeamId(teamId));
        }
        foundTeam = new Team(teamId, teamDto.Name, teamDto.PlayerId);


        await _logic.Update(foundTeam);

        return Ok("Finished Updating");
    }
}