using ApplicationLayer;
using AutoMapper;
using DataLayer.DataGenerator;
using DataLayer.Domain;
using DataLayer.Dto;
using DomainLayer.Logic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using WuHuAPI.Info;

namespace WuHuAPI.Controllers;

// --------------------- Create Update Get Player For Admin and Player -----------------------
// --------------------- Create and Update NOT allowed for normal Player -----------------------
[ApiController]
[Route("api/[controller]s")]
public class PlayerController : ControllerBase
{

    private readonly IManagementLogic<Player> _logic;
    private readonly IManagementLogic<User> _logicUser;
    private readonly IMapper _mapper;

    public readonly GamePlan _gamePlan;

    public PlayerController(IManagementLogic<Player> logic, IManagementLogic<User> logicUser, GamePlan gamePlan, IMapper mapper)
    {
        _logic = logic;
        _logicUser = logicUser;
        _gamePlan = gamePlan;
        _mapper = mapper;
    }
    private async Task<PlayerDto?> GetLast()
    {
        var players = await _logic.GetAll();
        return _mapper.Map<PlayerDto>(players.LastOrDefault());
    }


    /// <summary>
    /// Returns a Player by PlayerID.
    /// </summary>
    /// <param name="PlayerId">ID</param>      
    /// <returns>The Player with the given ID</returns>
    [HttpGet("{PlayerId}")]
    public async Task<ActionResult<PlayerDto>> GetPlayerById(int PlayerId)
    {
        Player? player = await _logic.Search(PlayerId);
        if (player is null)
        {
            return NotFound(StatusInfo.InvalidPersonId(PlayerId));
        }
        //return Ok(Player.ToDto());
        return _mapper.Map<PlayerDto>(player);
    }

    /// <summary>
    /// Returns a list of Players
    /// </summary>
    /// <returns>a list of Players</returns>
    [HttpGet]
    public async Task<IEnumerable<PlayerDto>> GetPlayers()
    {
        var players = await _logic.GetAll();
        return _mapper.Map<IEnumerable<PlayerDto>>(players);
    }

    /// <summary>
    /// Returns a created Player with the id after creating a Player
    /// </summary>
    [HttpPost]
    //[Authorize]
    public async Task<ActionResult<PlayerDto>> CreatePlayer([FromBody] PlayerDto playerDto)
    {
        var iDict = new Dictionary<string, object>();
        iDict.Add("FullName", playerDto.FullName);
        iDict.Add("NickName", playerDto.NickName);
        iDict.Add("PhotoUrl", playerDto.PhotoUrl);
        iDict.Add("Strength", playerDto.Strength);

        IEnumerable<Player?> foundPlayer = await _logic.GetTByX(iDict);
        if (foundPlayer.IsNullOrEmpty())
        {
            var count = await _logic.CountAll();
            Player newPlayer = new Player(foundPlayer.ToArray()[0]!.Id, foundPlayer.ToArray()[0]!.FullName, foundPlayer.ToArray()[0]!.NickName, foundPlayer.ToArray()[0]!.PhotoUrl, foundPlayer.ToArray()[0]!.Strength);

            await _logic.Add(newPlayer);
            return CreatedAtAction(actionName: nameof(GetPlayerById),
                routeValues: new { PlayerId = newPlayer.Id },
                //value: Player.ToDto()
                value: _mapper.Map<PlayerDto>(newPlayer)
                );
        }

        return NoContent();
    }

    /// <summary>
    /// Returns a created List of Players with the id after creating a Player
    /// </summary>
    [HttpPost("create-mock-user-player/{numberOfWantedPlayer}")]
    //[Authorize]
    public async Task<IEnumerable<PlayerDto>> CreateMockUserPlayer(int numberOfWantedPlayer)
    {

        List<(User, Player)> list_user_player = DataGenerator.GenerateUsersAndPlayersWithMinimumPlayerCount(numberOfWantedPlayer);

        IEnumerable<User> users = list_user_player.Select(tuple => tuple.Item1);
        IEnumerable<Player> players = list_user_player.Where(tuple => tuple.Item2 != null).Select(tuple => tuple.Item2);

        var testStoreAll = await _logicUser.AddAll(users);
        
        var checkAg= await _logic.AddAll(players);
        

        return (_mapper.Map<IEnumerable<PlayerDto>>(players));
    }

    /// <summary>
    /// Update a Player with the Player id given and show it back if success updating
    /// </summary>
    [HttpPut("{PlayerId}")]
    //[Authorize]
    public async Task<ActionResult<PlayerDto>> UpdatePlayer(int PlayerId, [FromBody] PlayerDto playerDto)
    {
        Player? foundPlayer = (Player?)await _logic.Search(PlayerId);
        if (foundPlayer is null)
        {
            return NotFound(StatusInfo.InvalidPersonId(PlayerId));
        }
        foundPlayer = new Player(PlayerId, playerDto.FullName, playerDto.NickName, playerDto.PhotoUrl, playerDto.Strength);


        await _logic.Update(foundPlayer);

        return Ok("Finished Updating");
    }


    /// <summary>
    /// Delete a Player with the Player-id given
    /// </summary>
    [HttpDelete("{PlayerId}")]
    //[Authorize]
    public async Task<ActionResult> DeletePlayer([FromRoute] int playerId)
    {
        if (await _logic.Delete(playerId))
        {
            return Ok("Finished Deleting");
        }
        else
        {
            return NotFound();
        }
    }

}