﻿using ApplicationLayer;
using AutoMapper;
using DataLayer.Domain;
using DataLayer.Dto;
using Microsoft.AspNetCore.Mvc;
using SecurityLayer;
using WuHuAPI.Info;

namespace WuHuAPI.Controllers;


// ----------------------- Authorization && Authentication -------------------------------
// -----------------Bearer Token = Token based Authorization using JWT Token -------------
[Route("api/[controller]s")]
[ApiController]
[ApiConventionType(typeof(WebApiConventions))]
public class AuthorizationForUserController : ControllerBase
{
    private readonly IAuthenticate _auth;
    
    

    public AuthorizationForUserController(IAuthenticate auth, IMapper mapper)
    {
        this._auth = auth;        
        _auth.setMapper(mapper ?? throw new ArgumentNullException(nameof(mapper)));
    }

    [HttpPost("login")]
    public async Task<IActionResult> UserLogin([FromBody] UserDto user)
    {
        var result = await _auth.AuthenticateUser(user);
        if (result is null)
        {
            return NotFound("Wrong Email or Password");
        }
        return Ok(result);
    }

}
