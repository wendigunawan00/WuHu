﻿using Microsoft.AspNetCore.Mvc;


namespace WuHuAPI.Info;

public static class StatusInfo
{
    public static ProblemDetails InvalidPersonId(int playerId) => new ProblemDetails
    {
        Title = "Invalid Person ID",
        Detail = $"Person with ID '{playerId}' does not exist"
    }; 
    
    public static ProblemDetails InvalidEmail(int email) => new ProblemDetails
    {
        Title = "Invalid Person ID",
        Detail = $"Person with ID '{email}' does not exist"
    }; 
    public static ProblemDetails InvalidTeamId(string teamId) => new ProblemDetails
    {
        Title = "Invalid Team ID",
        Detail = $"Team with ID '{teamId}' does not exist"
    };
    public static ProblemDetails InvalidMatchId(string matchId) => new ProblemDetails
    {
        Title = "Invalid match ID",
        Detail = $"match with ID '{matchId}' does not exist"
    };
    public static ProblemDetails InvalidTeamNumber(string teamName) => new ProblemDetails
    {
        Title = "Invalid Team number",
        Detail = $"Team with an id '{teamName}' has not enough player"
    };

   
    
}
