﻿using AutoMapper;
using DataLayer.Dto;
using DataLayer.Domain;

namespace WuHuAPI.Profiles;


public class PlayerProfile:Profile
{
    public PlayerProfile()
    {
        CreateMap<Player, PlayerDto>();
        CreateMap<PlayerDto, Player>();      
    }
}
