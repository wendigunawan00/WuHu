﻿using AutoMapper;
using DataLayer.Dto;
using DataLayer.Domain;


namespace WuHuAPI.Profiles;

public class TeamProfile:Profile

{
    public TeamProfile()
    {
        CreateMap<Team, TeamDto>();
        CreateMap<TeamDto, Team>();
    }
}

