﻿using AutoMapper;
using DataLayer.Dto;
using DataLayer.Domain;

namespace WuHuAPI.Profiles;

public class AttendanceTimeProfile:Profile
{
    public AttendanceTimeProfile()
    {
        CreateMap<AttendanceTimeDto,AttendanceTime>();
        CreateMap<AttendanceTime, AttendanceTimeDto>();
    }
}
