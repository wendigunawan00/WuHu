﻿using AutoMapper;
using DataLayer.Dto;
using DataLayer.Domain;

namespace WuHuAPI.Profiles;

public class MatchProfile:Profile
{
    public MatchProfile()
    {
        CreateMap<Match, MatchDto>();
        CreateMap<MatchDto, Match>();
    }
}
