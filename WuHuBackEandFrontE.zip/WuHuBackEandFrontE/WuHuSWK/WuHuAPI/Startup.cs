﻿using ApplicationLayer;
using ApplicationLayer.Impl;
using DataLayer.Dao;
using DataLayer.Dao.DaoImpl;
using DataLayer.Domain;
using DataLayer.Dto;
using DomainLayer.Logic;
using InfrastructureLayer.Common;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using SecurityLayer;
using SecurityLayer.Impl;
using System.Text;


namespace WuHuAPI;

public class Startup
{
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    public IConfiguration Configuration { get; }

    public void ConfigureServices(IServiceCollection services)
    {
        services.AddRouting(options => options.LowercaseUrls = true);
        services.AddControllers()
            .AddNewtonsoftJson()
            .AddXmlDataContractSerializerFormatters();

        services.AddAuthentication(option =>
        {
            option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            option.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
        }).AddJwtBearer(option =>
        {
            option.SaveToken = true;
            option.RequireHttpsMetadata = false;
            option.TokenValidationParameters = new TokenValidationParameters()
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidAudience = ConfigurationUtil.GetConfiguration()["JWT:ValidAudience"],
                ValidIssuer = ConfigurationUtil.GetConfiguration()["JWT:ValidIssuer"],
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(ConfigurationUtil.GetConfiguration()["JWT:Key"]))
            };
        });

        services.AddMvc();
        services.AddScoped<IManagementLogic<Match>>(_ =>
            new ManagementLogic<Match>(new AdoGenericDao<Match>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Matches$")
        );
        services.AddScoped<IManagementLogic<Team>>(_ =>
            new ManagementLogic<Team>(new AdoGenericDao<Team>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Teams$")
        );
        services.AddScoped<IManagementLogic<User>>(_ =>
            new ManagementLogic<User>(new AdoGenericDao<User>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Users$")
        );
        services.AddScoped<IAuthenticate>(_ =>
            new Authenticate(new AdoGenericDao<User>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Users$")
        );
        services.AddScoped<IManagementLogic<Player>>(_ =>
            new ManagementLogic<Player>(new AdoGenericDao<Player>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Players$")
        );
        services.AddScoped<IManagementLogic<AttendanceTime>>(_ =>
            new ManagementLogic<AttendanceTime>(new AdoGenericDao<AttendanceTime>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "AttendanceTimes$")
        );
        services.AddScoped<IManagementLogic<PlayingTime>>(_ =>
            new ManagementLogic<PlayingTime>(new AdoGenericDao<PlayingTime>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "PlayingTimes$")
        );
        //services.AddScoped<IGenericDao<Match>,AdoGenericDao<Match>>();        
        //services.AddSingleton<PlayerStrengthGenerator>(_=> new PlayerStrengthGenerator(new AdoGenericDao<Player>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Players$"));

        services.AddHostedService<PlayerStrengthUpdateService>(_ => 
        new PlayerStrengthUpdateService(
            new PlayerStrengthGenerator(new AdoGenericDao<Player>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), "Players$"),
            new AdoGenericDao<Match>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection") ))
            
        );

        //services.AddScoped<IGenericDao<Player>, AdoGenericDao<Player>>();
        //services.AddScoped<IGenericDao<Team>, AdoGenericDao<Team>>();
        services.AddSingleton<GamePlan>(_ => new GamePlan(
            new AdoGenericDao<Team>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")),
          new AdoGenericDao<Player>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), 
          new AdoGenericDao<AttendanceTime>(DefaultConnectionFactory.FromConfiguration(ConfigurationUtil.GetConfiguration(), "WuHuDbConnection")), 
          new TeamNameSelectorFactory()
          ));
    

        services.AddAutoMapper(typeof(Program));
        services.AddCors(builder => builder.AddDefaultPolicy(
            policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

        services.AddOpenApiDocument(settings =>
        {
            settings.Title = "WuHu";
            settings.PostProcess = doc => doc.Info.Title = "WuHu";
        });
    }

    /*public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
            //app.UseSwagger();
            //app.UseSwaggerUi(c =>
            //{
            //    c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
            //    c.RoutePrefix = string.Empty;
            //});
            app.UseOpenApi();

            app.UseSwaggerUi3(settings => settings.Path = "/swagger");

        }
        else
        {
            app.UseExceptionHandler("/Error");
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseRouting();
        app.UseAuthentication();
        app.UseAuthorization();

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    }*/

    public void Configure(IApplicationBuilder app)
    {
        app.UseHttpsRedirection();
        app.UseStaticFiles();
        app.UseRouting();
        app.UseOpenApi();
        app.UseSwaggerUi3(settings => settings.Path = "/swagger");
        app.UseCors();
        app.UseAuthentication();
        app.UseAuthorization();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    }
}
