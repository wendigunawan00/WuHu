﻿using System.Data.Common;

namespace InfrastructureLayer.Common;

public interface IConnectionFactory
{
    string ConnectionString { get; }
    string ProviderName { get; }
    Task<DbConnection> CreateConnectionAsync();
    DbConnection? CreateConnectionSync();
}
