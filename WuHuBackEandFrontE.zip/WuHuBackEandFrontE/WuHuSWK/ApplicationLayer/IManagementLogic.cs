﻿namespace ApplicationLayer;

public interface IManagementLogic<T>
{
    Task<IEnumerable<T>> GetAll();
    Task<T?> Search(object id);
    Task<T?> GetLast();
    Task<int> CountAll();
    Task<bool> Add(T obj);
    Task<bool> AddAll(IEnumerable<T> obj);
    Task<bool> Update(T obj);
    Task<bool> Delete(object id);   
    Task<IEnumerable<T>> GetTByX(IDictionary<string, object> criteriaX);
    Task<int> CountTByX(IDictionary<string, object> criteriaX);
    Task<bool> IsValidTeam( object criteriaX);
}

