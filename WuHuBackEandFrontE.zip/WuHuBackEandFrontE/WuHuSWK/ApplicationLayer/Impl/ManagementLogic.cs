﻿using DataLayer.Dao;

namespace ApplicationLayer.Impl;

public class ManagementLogic<T> : IManagementLogic<T>
{
    private readonly IGenericDao<T> baseDao;
    private string table;


    public ManagementLogic(IGenericDao<T> baseDao, string DBTableName)
    {
        this.baseDao = baseDao ?? throw new ArgumentNullException(nameof(baseDao));
        table = DBTableName;
    }

    public async Task<IEnumerable<T>> GetAll()
    {
        return (IEnumerable<T>)await baseDao.FindAllAsync(table);
    }

    public async Task<int> CountAll()
    {
        return await baseDao.CountAllElements(table);
    }
    public async Task<bool> Add(T obj)
    {
        return await baseDao.StoreAsync(obj, table);
    }
    public async Task<bool> AddAll(IEnumerable<T> l_obj)
    {
        return await baseDao.StoreAllAsync(l_obj, table);
    }

    public async Task<bool> Update(T obj)
    {
        return await baseDao.UpdateAsync(obj, table);
    }

    public async Task<bool> Delete(object id)
    {
        return await baseDao.DeleteByIdAsync(id, table);
    }

    public async Task<T?> Search(object id)
    {
        return await baseDao.FindByIdAsync(id, table);
    }

    public async Task<T?> GetLast()
    {
        return await baseDao.FindLastAsync(table);
    }

    public async Task<IEnumerable<T>> GetTByX(IDictionary<string, object> criteriaX)
    {
        return (IEnumerable<T>)await baseDao.FindTByAnyCriteria(criteriaX, table);
    }

    public async Task<int> CountTByX(IDictionary<string, object> criteriaX)
    {
        return await baseDao.CountTWhereProperties(criteriaX,table);
    }
    
    public async Task<bool> IsValidTeam(object criteriaX)
    {
        IDictionary<string, object> iDictA = new Dictionary<string, object>();
        iDictA.Add("team1_name", criteriaX);
        int countTeamA = await baseDao.CountTWhereProperties(iDictA,table);

        return countTeamA >=11;
    }


}