﻿
using AutoMapper;
using DataLayer.Dao;
using DataLayer.Domain;
using DataLayer.Dto;
using InfrastructureLayer.Common;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace SecurityLayer.Impl;




public class Authenticate : IAuthenticate
{
    private IMapper _mapper;
    private readonly IGenericDao<User> _logic;
    private readonly string _table;

    public void setMapper(IMapper value)
    {
        _mapper = value;
    }

    public Authenticate(IGenericDao<User> logicUser, string table)
    {
        _logic = logicUser;
        _table = table;
    }


    private async Task<UserDto?> GetUserByEmailAndPassword(string email, string password)
    {
        string sql = $"SELECT * FROM {_table} WHERE email = @email AND password = @password)";
        var properties = new Dictionary<string, object>() {
            { "email", email },
            { "password", password }
        };
        return _mapper.Map<UserDto>(await _logic.FindTByProperties(properties, sql));
    }


    private string GetToken(UserDto admin)
    {
        IConfiguration config = ConfigurationUtil.GetConfiguration();
        var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]));
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
        var claims = new[]
        {
            new Claim(ClaimTypes.Email , admin.Email),
            new Claim(ClaimTypes.GivenName , admin.Username)
        };

        var token = new JwtSecurityToken(
            config["Jwt:ValidIssuer"],
            config["Jwt:ValidAudience"],
            claims,
            expires: DateTime.Now.AddMinutes(15),
            signingCredentials: credentials
            );
        return new JwtSecurityTokenHandler().WriteToken(token);

    }

    private string GetUserToken(UserDto user)
    {
        IConfiguration config = ConfigurationUtil.GetConfiguration();
        var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]));
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
        var claims = new[]
        {
            new Claim(ClaimTypes.Email , user.Email),
            new Claim(ClaimTypes.Sid , user.Password)
        };

        var token = new JwtSecurityToken(
            config["Jwt:ValidIssuer"],
            config["Jwt:ValidAudience"],
            claims,
            expires: DateTime.Now.AddMinutes(15),
            signingCredentials: credentials
            );
        return new JwtSecurityTokenHandler().WriteToken(token);

    }


    public async Task<string?> AuthenticateUser(UserDto user)
    {
        var reg_user = await GetUserByEmailAndPassword(user.Email, user.Password);
        if (reg_user is null)
        {
            return null;
        }
        if (reg_user.Role.Equals(UserRole.Spectator))
        {
            return GetUserToken(user);
        }
        if (reg_user.Role.Equals(UserRole.Administrator))
        {
            return GetToken(user);
        }

        return null;
    }

}

