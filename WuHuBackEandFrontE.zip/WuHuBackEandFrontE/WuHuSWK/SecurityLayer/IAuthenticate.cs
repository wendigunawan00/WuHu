﻿using AutoMapper;
using DataLayer.Dto;

namespace SecurityLayer;

public interface IAuthenticate
{
    Task<string?> AuthenticateUser(UserDto user);
    public void setMapper(IMapper mapper);
}